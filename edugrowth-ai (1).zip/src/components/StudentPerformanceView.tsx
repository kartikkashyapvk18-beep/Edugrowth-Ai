import React, { useState, useMemo, useRef, useEffect } from "react";
import { 
  TrendingUp, 
  TrendingDown, 
  User, 
  Clock, 
  Award, 
  AlertTriangle, 
  BookOpen, 
  Sparkles, 
  ArrowRight,
  Send,
  HelpCircle,
  FileCheck,
  CheckCircle2,
  BookmarkCheck
} from "lucide-react";
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  BarChart, 
  Bar, 
  Cell, 
  Legend
} from "recharts";

interface SubjectScore {
  name: string;
  value: number;
}

interface WeeklyScore {
  week: string;
  score: number;
}

interface StudentPerformance {
  id: number;
  name: string;
  batch: string;
  rank: number;
  overallScore: number;
  dppCompletion: number;
  trend: "Upward" | "Stable" | "Downward";
  weeklyScores: WeeklyScore[];
  subjects: SubjectScore[];
}

// User suggested mock data with exact student cohort
const studentsPerformanceData: StudentPerformance[] = [
  { 
    id: 1, name: "Tanmay Verma", batch: "JEE Main + Advanced", rank: 1, overallScore: 94, dppCompletion: 98, trend: "Upward",
    weeklyScores: [{ week: 'W1', score: 82 }, { week: 'W2', score: 88 }, { week: 'W3', score: 91 }, { week: 'W4', score: 94 }],
    subjects: [{ name: 'Physics', value: 96 }, { name: 'Chemistry', value: 90 }, { name: 'Maths', value: 95 }]
  },
  { 
    id: 2, name: "Manish Chabra", batch: "12th Board + CUET", rank: 2, overallScore: 86, dppCompletion: 92, trend: "Upward",
    weeklyScores: [{ week: 'W1', score: 75 }, { week: 'W2', score: 80 }, { week: 'W3', score: 82 }, { week: 'W4', score: 86 }],
    subjects: [{ name: 'Accounts', value: 89 }, { name: 'Economics', value: 84 }, { name: 'Business', value: 85 }]
  },
  { 
    id: 3, name: "Lekhani Khatri", batch: "CA Foundation", rank: 3, overallScore: 78, dppCompletion: 85, trend: "Stable",
    weeklyScores: [{ week: 'W1', score: 76 }, { week: 'W2', score: 79 }, { week: 'W3', score: 77 }, { week: 'W4', score: 78 }],
    subjects: [{ name: 'Law', value: 72 }, { name: 'Accounts', value: 85 }, { name: 'Maths', value: 77 }]
  },
  { 
    id: 4, name: "Deepak Yogi", batch: "NEET UG", rank: 4, overallScore: 68, dppCompletion: 74, trend: "Stable",
    weeklyScores: [{ week: 'W1', score: 62 }, { week: 'W2', score: 65 }, { week: 'W3', score: 69 }, { week: 'W4', score: 68 }],
    subjects: [{ name: 'Biology', value: 78 }, { name: 'Physics', value: 58 }, { name: 'Chemistry', value: 68 }]
  },
  { 
    id: 5, name: "Kartik Kashyap", batch: "CS Executive", rank: 5, overallScore: 55, dppCompletion: 58, trend: "Downward",
    weeklyScores: [{ week: 'W1', score: 65 }, { week: 'W2', score: 60 }, { week: 'W3', score: 58 }, { week: 'W4', score: 55 }],
    subjects: [{ name: 'Company Law', value: 52 }, { name: 'Taxation', value: 48 }, { name: 'JIGL', value: 65 }]
  }
];

const COLORS = ['#d11a2a', '#4F46E5', '#10B981', '#F59E0B', '#8B5CF6'];

interface StudentPerformanceViewProps {
  onNavigateToTab?: (tab: 'dashboard' | 'leads' | 'students' | 'settings' | 'doubt-solver' | 'dpp-quiz', stateParams?: any) => void;
}

export default function StudentPerformanceView({ onNavigateToTab }: StudentPerformanceViewProps) {
  const [selectedStudent, setSelectedStudent] = useState<StudentPerformance>(studentsPerformanceData[0]);
  const [nudgeMessage, setNudgeMessage] = useState<string | null>(null);
  const [isNudging, setIsNudging] = useState(false);
  const [copyFeedback, setCopyFeedback] = useState(false);

  // Timer ref to prevent unmount state updates
  const nudgeTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    return () => {
      if (nudgeTimeoutRef.current) clearTimeout(nudgeTimeoutRef.current);
    };
  }, []);

  // Computations
  const batchStats = useMemo(() => {
    const totalScores = studentsPerformanceData.reduce((acc, s) => acc + s.overallScore, 0);
    const avgAccuracy = Math.round(totalScores / studentsPerformanceData.length * 10) / 10;
    
    const totalDpp = studentsPerformanceData.reduce((acc, s) => acc + s.dppCompletion, 0);
    const avgDppRatio = Math.round(totalDpp / studentsPerformanceData.length * 10) / 10;

    const leader = [...studentsPerformanceData].sort((a, b) => b.overallScore - a.overallScore)[0];
    const interventions = studentsPerformanceData.filter(s => s.overallScore < 75).length;

    return {
      avgAccuracy,
      avgDppRatio,
      leader,
      interventions
    };
  }, []);

  // Compute weakest subject
  const weakestSubjectObj = useMemo(() => {
    return selectedStudent.subjects.reduce((prev, current) => (prev.value < current.value) ? prev : current);
  }, [selectedStudent]);

  // Handle auto-routing integrations
  const triggerCustomDPP = () => {
    if (onNavigateToTab) {
      onNavigateToTab('dpp-quiz', { 
        topic: weakestSubjectObj.name,
        difficulty: selectedStudent.overallScore < 70 ? "Fundamental" : "Moderate"
      });
    }
  };

  const triggerSaarthiSolve = () => {
    if (onNavigateToTab) {
      onNavigateToTab('doubt-solver', {
        course: selectedStudent.batch.includes("JEE") ? "JEE" : selectedStudent.batch.includes("NEET") ? "NEET" : selectedStudent.batch.includes("CA") ? "CA Foundation" : "UPSC",
        doubt: `Explain the fundamental tricky concepts of ${weakestSubjectObj.name} that are usually asked as high scoring MCQ questions in ${selectedStudent.batch}.`
      });
    }
  };

  // Generate automated AI Nudge on the client side
  const handleGenerateNudge = () => {
    setIsNudging(true);
    setNudgeMessage(null);
    
    if (nudgeTimeoutRef.current) clearTimeout(nudgeTimeoutRef.current);

    nudgeTimeoutRef.current = setTimeout(() => {
      let msg = "";
      if (selectedStudent.trend === "Downward") {
        msg = `Hi ${selectedStudent.name}! Kunal Verma here from EduGrowth AI. 📚 Notice kiya ki custom mock test score down chal raha hai, specifically *${weakestSubjectObj.name}* (${weakestSubjectObj.value}% accuracy). Ghabrana nahi hai, chalo live screen par doubt clear karein solutions ke sath! Connect tomorrow?`;
      } else if (selectedStudent.overallScore < 75) {
        msg = `Hi ${selectedStudent.name}! 😊 Weekly analysis me dekha aapki overall performance holds at *${selectedStudent.overallScore}%*. Humara target *85%+* hai. I've prepared a specialized revision formula for *${weakestSubjectObj.name}*, let's crack it together! 🙌`;
      } else {
        msg = `Hi *${selectedStudent.name}*! Super proud of your rank and consistency! 🏆 Your current DPP completion rate is an outstanding *${selectedStudent.dppCompletion}%*. Let's tackle some advanced 2026 HOTS questions next. Keep learning! 🔥`;
      }
      setNudgeMessage(msg);
      setIsNudging(false);
    }, 600);
  };

  return (
    <div className="space-y-6" id="student-performance-dashboard">
      
      {/* Top Batch Overview Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4" id="cohort-stats-grid">
        
        {/* Metric 1 */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs space-y-1" id="stat-accuracy">
          <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest block">Batch Avg Accuracy</span>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-extrabold text-[#d11a2a]">{batchStats.avgAccuracy}%</span>
            <span className="text-[10px] text-emerald-600 font-bold flex items-center bg-emerald-50 px-1.5 py-0.5 rounded leading-none">
              ▲ +1.8%
            </span>
          </div>
          <span className="text-[10px] text-slate-400 block">Calculated from final 5 mock cohorts</span>
        </div>

        {/* Metric 2 */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs space-y-1" id="stat-dpp">
          <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest block">Core DPP Engagement</span>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-extrabold text-indigo-700">{batchStats.avgDppRatio}%</span>
            <span className="text-[10px] text-indigo-600 font-extrabold bg-indigo-50 px-1.5 py-0.5 rounded leading-none">
              Active
            </span>
          </div>
          <span className="text-[10px] text-slate-400 block">Exam clearance lock threshold is 90%</span>
        </div>

        {/* Metric 3 */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs space-y-1" id="stat-leader">
          <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest block">Batch Cohort Leader</span>
          <div className="flex items-center gap-1.5">
            <span className="text-xs">👑</span>
            <span className="text-sm font-bold text-amber-700 truncate max-w-160">{batchStats.leader.name}</span>
          </div>
          <span className="text-[10px] text-slate-400 block truncate">{batchStats.leader.batch} &bull; Score: {batchStats.leader.overallScore}%</span>
        </div>

        {/* Metric 4 */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs space-y-1" id="stat-interventions">
          <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest block">Action Required Nudges</span>
          <div className="flex items-baseline gap-1.5">
            <span className="text-2xl font-extrabold text-rose-600">{batchStats.interventions}</span>
            <span className="text-[10px] text-rose-500 font-extrabold bg-rose-50 px-2 py-0.5 rounded leading-none">
              High Priority
            </span>
          </div>
          <span className="text-[10px] text-slate-400 block">Students scoring below 75% target threshold</span>
        </div>

      </div>

      {/* Main Student Workspace Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="performance-main-row">
        
        {/* Left Side: Student Selection list */}
        <div className="lg:col-span-4 space-y-4" id="cohort-students-list">
          <div className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-sm space-y-4">
            <h3 className="font-extrabold text-xs text-slate-400 uppercase tracking-widest border-b border-slate-100 pb-2">
              Cohort Leaderboard
            </h3>

            <div className="space-y-2">
              {studentsPerformanceData.map((student) => {
                const isSelected = selectedStudent.id === student.id;
                const isNudgeNeeded = student.overallScore < 75;

                return (
                  <button
                    key={student.id}
                    type="button"
                    onClick={() => {
                      setSelectedStudent(student);
                      setNudgeMessage(null);
                    }}
                    className={`w-full text-left p-3.5 rounded-xl border transition-all flex items-center justify-between group ${
                      isSelected 
                        ? "bg-[#d11a2a]/10 border-[#d11a2a] text-[#141d23]" 
                        : "bg-white border-slate-150 hover:bg-slate-50 text-slate-600"
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold text-xs ${
                        isSelected 
                          ? "bg-[#d11a2a] text-white" 
                          : "bg-slate-105 text-slate-600"
                      }`}>
                        #{student.rank}
                      </div>
                      <div>
                        <strong className={`text-xs block font-bold ${
                          isSelected ? "text-[#d11a2a]" : "text-slate-800"
                        }`}>{student.name}</strong>
                        <span className="text-[10px] text-slate-400 block mt-0.5 leading-none">{student.batch}</span>
                      </div>
                    </div>

                    <div className="text-right flex items-center gap-2">
                      <div className="space-y-0.5">
                        <span className="text-xs font-extrabold block">{student.overallScore}%</span>
                        <span className="text-[9px] text-slate-400 block font-semibold leading-none">Accuracy</span>
                      </div>
                      
                      {isNudgeNeeded && (
                        <span className="w-1.5 h-1.5 rounded-full bg-rose-500 animate-pulse" title="Requires Nudge" />
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Prompt/Interactive Student Quick Actions card */}
          <div className="bg-gradient-to-br from-indigo-900 to-indigo-950 rounded-2xl p-5 text-white shadow-md space-y-4" id="personalized-coaching-box">
            <div className="space-y-1">
              <span className="text-[9px] font-extrabold text-indigo-300 uppercase tracking-widest block">AI Guided Insights</span>
              <h4 className="text-sm font-black flex items-center gap-1">
                <Sparkles className="w-4 h-4 text-emerald-400 fill-emerald-405" />
                Coaching Actions: {selectedStudent.name}
              </h4>
              <p className="text-[11px] text-indigo-100/90 leading-relaxed">
                We detected {selectedStudent.name} is relatively weak in <strong className="text-orange-300 font-bold">{weakestSubjectObj.name}</strong> (Accuracy: {weakestSubjectObj.value}%). Apply the following strategies:
              </p>
            </div>

            <div className="space-y-2 border-t border-indigo-800 pt-3">
              <button
                onClick={triggerCustomDPP}
                className="w-full text-left p-3 rounded-lg bg-indigo-850 hover:bg-slate-800 border border-indigo-700 hover:border-indigo-400 transition-all flex justify-between items-center text-xs group"
              >
                <div className="flex items-center gap-2">
                  <BookmarkCheck className="w-4 h-4 text-green-400" />
                  <span>Spin up custom {weakestSubjectObj.name} DPP</span>
                </div>
                <ArrowRight className="w-3.5 h-3.5 text-indigo-300 group-hover:translate-x-1 transition-transform" />
              </button>

              <button
                onClick={triggerSaarthiSolve}
                className="w-full text-left p-3 rounded-lg bg-indigo-850 hover:bg-slate-800 border border-indigo-700 hover:border-indigo-400 transition-all flex justify-between items-center text-xs group"
              >
                <div className="flex items-center gap-2">
                  <HelpCircle className="w-4 h-4 text-orange-400" />
                  <span>Ask Saarthi for weak concepts</span>
                </div>
                <ArrowRight className="w-3.5 h-3.5 text-indigo-300 group-hover:translate-x-1 transition-transform" />
              </button>
            </div>
          </div>
        </div>

        {/* Right Side: Visual Metrics Dashboard */}
        <div className="lg:col-span-8 space-y-6" id="visuals-dashboard">
          
          <div className="bg-white rounded-2xl border border-slate-200/80 p-6 shadow-sm space-y-6">
            
            {/* Header info */}
            <div className="border-b border-slate-100 pb-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-slate-50 border border-slate-100 flex items-center justify-center text-xl">
                  {selectedStudent.trend === "Upward" ? "📈" : selectedStudent.trend === "Downward" ? "📉" : "📊"}
                </div>
                <div>
                  <h3 className="font-extrabold text-sm text-slate-800 flex items-center gap-1.5">
                    {selectedStudent.name}
                    <span className={`text-[10px] px-2 py-0.5 font-bold rounded-full ${
                      selectedStudent.trend === "Upward" 
                        ? "bg-emerald-50 text-emerald-700" 
                        : selectedStudent.trend === "Downward" 
                          ? "bg-rose-50 text-rose-700"
                          : "bg-slate-100 text-slate-600"
                    }`}>
                      {selectedStudent.trend} Trend
                    </span>
                  </h3>
                  <p className="text-[11px] text-slate-400 mt-0.5">{selectedStudent.batch}</p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <div className="text-center px-4 py-2 bg-slate-50 border border-slate-100 rounded-xl">
                  <span className="text-sm font-black text-slate-800 block">#{selectedStudent.rank}</span>
                  <span className="text-[9px] text-slate-400 block font-bold uppercase tracking-wider">Cohort Rank</span>
                </div>
                <div className="text-center px-4 py-2 bg-[#d11a2a]/5 border border-[#d11a2a]/10 rounded-xl">
                  <span className="text-sm font-black text-[#d11a2a] block">{selectedStudent.dppCompletion}%</span>
                  <span className="text-[9px] text-[#d11a2a] block font-bold uppercase tracking-wider">DPP Rate</span>
                </div>
              </div>
            </div>

            {/* Core Charts Area */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6" id="student-visual-charts">
              
              {/* Chart 1: Weekly Score progressions */}
              <div className="space-y-2 border border-slate-100 p-4 rounded-xl shadow-2xs">
                <h4 className="text-xs font-extrabold text-slate-500 uppercase tracking-widest flex items-center gap-1.5 mb-1 bg-white">
                  <TrendingUp className="w-4 h-4 text-slate-400" />
                  Weekly Progress (Accuracy Score)
                </h4>
                <div className="h-44 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={selectedStudent.weeklyScores} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                      <XAxis dataKey="week" stroke="#94a3b8" fontSize={10} tickLine={false} />
                      <YAxis stroke="#94a3b8" fontSize={10} tickLine={false} domain={[0, 100]} />
                      <Tooltip 
                        contentStyle={{ fontSize: "11px", borderRadius: "8px", border: "1px style rgb(241, 245, 249)" }}
                        labelStyle={{ fontWeight: "bold" }}
                      />
                      <Line 
                        type="monotone" 
                        dataKey="score" 
                        stroke="#d11a2a" 
                        strokeWidth={3} 
                        dot={{ r: 4, strokeWidth: 1 }} 
                        activeDot={{ r: 6 }} 
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Chart 2: Subject Accuracy breakout */}
              <div className="space-y-2 border border-slate-100 p-4 rounded-xl shadow-2xs">
                <h4 className="text-xs font-extrabold text-slate-500 uppercase tracking-widest flex items-center gap-1.5 mb-1 bg-white">
                  <BookOpen className="w-4 h-4 text-slate-400" />
                  Subject Performance Metrics (%)
                </h4>
                <div className="h-44 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={selectedStudent.subjects} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                      <XAxis dataKey="name" stroke="#94a3b8" fontSize={10} tickLine={false} />
                      <YAxis stroke="#94a3b8" fontSize={10} tickLine={false} domain={[0, 100]} />
                      <Tooltip 
                        contentStyle={{ fontSize: "11px", borderRadius: "8px", border: "1px style rgb(241, 245, 249)" }}
                      />
                      <Bar dataKey="value" fill="#4F46E5" radius={[6, 6, 0, 0]} maxBarSize={32}>
                        {selectedStudent.subjects.map((entry, index) => (
                          <Cell 
                            key={`cell-${index}`} 
                            fill={entry.name === weakestSubjectObj.name ? "#ef4444" : COLORS[index % COLORS.length]} 
                          />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>

            </div>

          </div>

          {/* AI WhatsApp Nudge Drafting box */}
          <div className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-sm space-y-4" id="nudge-draft-playground">
            <div className="flex justify-between items-center">
              <div>
                <h4 className="font-extrabold text-xs text-slate-500 uppercase tracking-widest">
                  Personalized Student WhatsApp Nudge
                </h4>
                <p className="text-[11px] text-slate-400">Draft empathetic academic progress pushes from Senior Counselor Kunal Verma</p>
              </div>

              <button
                type="button"
                onClick={handleGenerateNudge}
                disabled={isNudging}
                className="px-3.5 py-1.5 bg-[#d11a2a]/10 hover:bg-[#d11a2a]/20 text-[#d11a2a] rounded-lg text-xs font-bold transition-all flex items-center gap-1"
              >
                <Sparkles className="w-3.5 h-3.5 text-[#d11a2a]" />
                {isNudging ? "Drafting..." : "Generate Nudge"}
              </button>
            </div>

            {nudgeMessage ? (
              <div className="space-y-3 animate-fade-in" id="active-nudge-preview">
                <div className="bg-emerald-50/40 border border-emerald-100 p-4 rounded-xl space-y-2">
                  <span className="text-[10px] text-emerald-700 font-extrabold uppercase tracking-widest block flex items-center gap-1">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    Ready WhatsApp Outreach Draft
                  </span>
                  <p className="text-slate-800 text-xs leading-relaxed font-mono whitespace-pre-wrap">{nudgeMessage}</p>
                </div>

                <div className="flex justify-end gap-2">
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(nudgeMessage || "");
                      setCopyFeedback(true);
                      setTimeout(() => setCopyFeedback(false), 2500);
                    }}
                    className={`px-4 py-2 border transition-all font-bold rounded-lg text-xs ${
                      copyFeedback 
                        ? 'bg-emerald-50 text-emerald-600 border-emerald-200 shadow-xs' 
                        : 'border-slate-200 hover:bg-slate-50 text-slate-600'
                    }`}
                  >
                    {copyFeedback ? "✓ Copied to Clipboard!" : "Copy Text"}
                  </button>

                  <a
                    href={`https://wa.me/${selectedStudent.id === 1 ? "919876543210" : "918765432109"}?text=${encodeURIComponent(nudgeMessage)}`}
                    target="_blank"
                    referrerPolicy="no-referrer"
                    rel="noopener noreferrer"
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold rounded-lg text-xs transition-colors flex items-center gap-1.5"
                  >
                    <Send className="w-3.5 h-3.5" />
                    Send via Web WhatsApp
                  </a>
                </div>
              </div>
            ) : (
              <div className="bg-slate-50/50 border border-dashed border-slate-200/80 rounded-xl py-6 px-4 text-center">
                <p className="text-xs text-slate-400">
                  Click the "Generate Nudge" button above to dynamically draft a custom follow-up message tailored to {selectedStudent.name}'s weak chapters or top ranking metrics.
                </p>
              </div>
            )}
          </div>

        </div>

      </div>

    </div>
  );
}
