import React, { useState, useRef, useEffect } from "react";
import { 
  Send, Paperclip, Bell, Users, BookOpen, AlertCircle, Sparkles, 
  User, CheckCircle2, FileText, Image, Globe, RefreshCw, Layers,
  ChevronLeft, Trash2, ArrowRight, CornerDownRight, Check,
  X, Search, Download, ExternalLink
} from "lucide-react";

interface Attachment {
  name: string;
  size: string;
  type: "pdf" | "image" | "link";
  url?: string;
}

interface Message {
  id: string;
  senderName: string;
  role: "Teacher" | "Student" | "Admin";
  content: string;
  timestamp: string;
  avatarUrl?: string;
  attachment?: Attachment;
  channelId: string;
}

interface Channel {
  id: string;
  name: string;
  description: string;
  icon: string;
  readOnlyForStudents: boolean;
}

interface BatchChatViewProps {
  onActivityPerformed?: () => void;
}

export default function BatchChatView({ onActivityPerformed }: BatchChatViewProps = {}) {
  const [activeChannelId, setActiveChannelId] = useState<string>("discussion");
  const [currentUserRole, setCurrentUserRole] = useState<"Teacher" | "Student">("Teacher");
  const [messages, setMessages] = useState<Message[]>([
    // Announcements channel
    {
      id: "ann-1",
      senderName: "Kunal Verma",
      role: "Teacher",
      content: "🎯 **CRITICAL ADMISSION NOTIFICATION**: Today's class timing for \"Kepler's Cosmic Laws\" has been rescheduled to 4:00 PM. Make sure to complete the physics prep-sheets beforehand to easily solve doubts!",
      timestamp: "10:30 AM",
      avatarUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuBrvWwbdj5qPcyoAy4oUhKkWTjXmDsn-8qNR60EIxdSYvagG8RAgNTnKtl-RD2UPjm7Jc5fyMKjNdkI9VVldhWO-EAqfoCd6ug9MgonULT0U0UF7Wh1pqb88Qb5KD_uKbeZuBfWLWlBfFL6JTx860DJQkByUIddpXme1_ng1oOD05KeeiDr_S84ouHXvnzUEo_Uq0aYtnoyjyZfJ6yXDMnsN8UON0t0Sc0K6e4-G0hzQCzA84wx5xaGw0osc_xzOaUky14tkWgBW-4",
      channelId: "announcements"
    },
    {
      id: "ann-2",
      senderName: "Kunal Verma",
      role: "Teacher",
      content: "📚 **CA Foundation & JEE Cohorts Setup**: Weekly progress scores and stand-out entries are now updated in the \"Student Matrix\" tab. Check your standings and focus areas!",
      timestamp: "12:15 PM",
      avatarUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuBrvWwbdj5qPcyoAy4oUhKkWTjXmDsn-8qNR60EIxdSYvagG8RAgNTnKtl-RD2UPjm7Jc5fyMKjNdkI9VVldhWO-EAqfoCd6ug9MgonULT0U0UF7Wh1pqb88Qb5KD_uKbeZuBfWLWlBfFL6JTx860DJQkByUIddpXme1_ng1oOD05KeeiDr_S84ouHXvnzUEo_Uq0aYtnoyjyZfJ6yXDMnsN8UON0t0Sc0K6e4-G0hzQCzA84wx5xaGw0osc_xzOaUky14tkWgBW-4",
      channelId: "announcements"
    },
    {
      id: "ann-3",
      senderName: "Kunal Verma",
      role: "Teacher",
      content: "🔗 **Exam Portal Link**: Registration portal is now live at https://jeemain.nta.ac.in. Please complete and submit your application forms on time.",
      timestamp: "01:10 PM",
      avatarUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuBrvWwbdj5qPcyoAy4oUhKkWTjXmDsn-8qNR60EIxdSYvagG8RAgNTnKtl-RD2UPjm7Jc5fyMKjNdkI9VVldhWO-EAqfoCd6ug9MgonULT0U0UF7Wh1pqb88Qb5KD_uKbeZuBfWLWlBfFL6JTx860DJQkByUIddpXme1_ng1oOD05KeeiDr_S84ouHXvnzUEo_Uq0aYtnoyjyZfJ6yXDMnsN8UON0t0Sc0K6e4-G0hzQCzA84wx5xaGw0osc_xzOaUky14tkWgBW-4",
      channelId: "announcements"
    },

    // Discussion channel
    {
      id: "disc-1",
      senderName: "Aman Sharma",
      role: "Student",
      content: "Hey everyone! Is anyone working on the Kepler's Orbital Year numerical from practice DPP #4? That 1/4 radius reduction variable calculations are getting extremely tricky for me.",
      timestamp: "02:00 PM",
      channelId: "discussion"
    },
    {
      id: "disc-2",
      senderName: "Riya Jha",
      role: "Student",
      content: "Yes, Aman! Use Kepler's Third Law relation directly: $T^2 \\propto R^3$. If R reduces to $1/4$th, then new year duration $T_{\\text{new}} = (1/4)^{1.5} \\cdot T_{\\text{old}} = 1/8 \\cdot 365$ days! It saves so much calculation time.",
      timestamp: "02:05 PM",
      channelId: "discussion"
    },
    {
      id: "disc-3",
      senderName: "Vikram Seth",
      role: "Student",
      content: "Oh perfect, thanks Riya! I was making a very silly calculation error by just dividing by 4. Saving this formula hack immediately! 🙌",
      timestamp: "02:10 PM",
      channelId: "discussion"
    },
    {
      id: "disc-4",
      senderName: "Riya Jha",
      role: "Student",
      content: "Check out this visual reference grid. Here is the ellipse plot for Kepler's orbital parameters.",
      timestamp: "02:40 PM",
      attachment: {
        name: "Kepler_Orbital_Ellipses.jpg",
        size: "1.4 MB",
        type: "image",
        url: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?q=80&w=600&auto=format&fit=crop"
      },
      channelId: "discussion"
    },
    {
      id: "disc-5",
      senderName: "Kunal Verma",
      role: "Teacher",
      content: "Absolutely brilliant explanation, Riya! To back it up, watch this high-yield 3D simulation video lecture: https://www.youtube.com/watch?v=FjI8Y-v_BCE",
      timestamp: "03:00 PM",
      avatarUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuBrvWwbdj5qPcyoAy4oUhKkWTjXmDsn-8qNR60EIxdSYvagG8RAgNTnKtl-RD2UPjm7Jc5fyMKjNdkI9VVldhWO-EAqfoCd6ug9MgonULT0U0UF7Wh1pqb88Qb5KD_uKbeZuBfWLWlBfFL6JTx860DJQkByUIddpXme1_ng1oOD05KeeiDr_S84ouHXvnzUEo_Uq0aYtnoyjyZfJ6yXDMnsN8UON0t0Sc0K6e4-G0hzQCzA84wx5xaGw0osc_xzOaUky14tkWgBW-4",
      channelId: "discussion"
    },

    // Notes PDFs Channel
    {
      id: "note-1",
      senderName: "Kunal Verma",
      role: "Teacher",
      content: "Hello CA Aspirants! Here is the official comprehensive Masterclass PDF note on Partnership Goodwill journals. Print this out for your ledger checks.",
      timestamp: "Yesterday",
      avatarUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuBrvWwbdj5qPcyoAy4oUhKkWTjXmDsn-8qNR60EIxdSYvagG8RAgNTnKtl-RD2UPjm7Jc5fyMKjNdkI9VVldhWO-EAqfoCd6ug9MgonULT0U0UF7Wh1pqb88Qb5KD_uKbeZuBfWLWlBfFL6JTx860DJQkByUIddpXme1_ng1oOD05KeeiDr_S84ouHXvnzUEo_Uq0aYtnoyjyZfJ6yXDMnsN8UON0t0Sc0K6e4-G0hzQCzA84wx5xaGw0osc_xzOaUky14tkWgBW-4",
      attachment: {
        name: "Partnership_Goodwill_Masterclass.pdf",
        size: "2.4 MB",
        type: "pdf"
      },
      channelId: "notes"
    },
    {
      id: "note-2",
      senderName: "Kunal Verma",
      role: "Teacher",
      content: "Calvin cycle ATP pathways breakdown sheet for NEET biology. commit the 18 ATP / 12 NADPH metrics to memory. It's a high-frequency exam concept!",
      timestamp: "Yesterday",
      avatarUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuBrvWwbdj5qPcyoAy4oUhKkWTjXmDsn-8qNR60EIxdSYvagG8RAgNTnKtl-RD2UPjm7Jc5fyMKjNdkI9VVldhWO-EAqfoCd6ug9MgonULT0U0UF7Wh1pqb88Qb5KD_uKbeZuBfWLWlBfFL6JTx860DJQkByUIddpXme1_ng1oOD05KeeiDr_S84ouHXvnzUEo_Uq0aYtnoyjyZfJ6yXDMnsN8UON0t0Sc0K6e4-G0hzQCzA84wx5xaGw0osc_xzOaUky14tkWgBW-4",
      attachment: {
        name: "Calvin_Pathway_Photosynthesis_NEET.pdf",
        size: "1.8 MB",
        type: "pdf"
      },
      channelId: "notes"
    },
    {
      id: "note-3",
      senderName: "Kunal Verma",
      role: "Teacher",
      content: "Here is the visual mapping infographic worksheet for the Goodwill Partnership schedules ledger adjustments:",
      timestamp: "Yesterday",
      avatarUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuBrvWwbdj5qPcyoAy4oUhKkWTjXmDsn-8qNR60EIxdSYvagG8RAgNTnKtl-RD2UPjm7Jc5fyMKjNdkI9VVldhWO-EAqfoCd6ug9MgonULT0U0UF7Wh1pqb88Qb5KD_uKbeZuBfWLWlBfFL6JTx860DJQkByUIddpXme1_ng1oOD05KeeiDr_S84ouHXvnzUEo_Uq0aYtnoyjyZfJ6yXDMnsN8UON0t0Sc0K6e4-G0hzQCzA84wx5xaGw0osc_xzOaUky14tkWgBW-4",
      attachment: {
        name: "Goodwill_Ledger_Schedules.jpg",
        size: "950 KB",
        type: "image",
        url: "https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?q=80&w=600&auto=format&fit=crop"
      },
      channelId: "notes"
    }
  ]);

  const channels: Channel[] = [
    {
      id: "announcements",
      name: "Announcements (Admin Only)",
      description: "Official notifications, schedules, and test announcements strictly from teachers.",
      icon: "📢",
      readOnlyForStudents: true,
    },
    {
      id: "discussion",
      name: "Peer Discussion",
      description: "Ask questions, share updates, solve peer doubts, and build competitive spirit.",
      icon: "💬",
      readOnlyForStudents: false,
    },
    {
      id: "notes",
      name: "Shared Notes",
      description: "Direct library of curated books, physics formula notes, and mock worksheets.",
      icon: "📚",
      readOnlyForStudents: false,
    }
  ];

  const [inputText, setInputText] = useState("");
  const [showAttachmentMenu, setShowAttachmentMenu] = useState(false);
  const [selectedAttachment, setSelectedAttachment] = useState<Attachment | null>(null);
  const [mobileActivePane, setMobileActivePane] = useState<"sidebar" | "chat">("sidebar");
  const [isTypingSimulated, setIsTypingSimulated] = useState(false);

  // Sleek Media/Document Resource Drawer State Managers
  const [isMediaDrawerOpen, setIsMediaDrawerOpen] = useState(false);
  const [drawerActiveTab, setDrawerActiveTab] = useState<"media" | "docs" | "links">("media");
  const [docSearchQuery, setDocSearchQuery] = useState("");

  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Non-blocking custom chat alert toasts inside the workspace sandbox
  const [chatToast, setChatToast] = useState<string | null>(null);
  const chatToastTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const showChatToast = (message: string) => {
    if (chatToastTimeoutRef.current) clearTimeout(chatToastTimeoutRef.current);
    setChatToast(message);
    chatToastTimeoutRef.current = setTimeout(() => {
      setChatToast(null);
    }, 4000);
  };

  // Safe timer references for simulating replies
  const chatSimTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Memory cleanup effect on unmount
  useEffect(() => {
    return () => {
      if (chatToastTimeoutRef.current) clearTimeout(chatToastTimeoutRef.current);
      if (chatSimTimeoutRef.current) clearTimeout(chatSimTimeoutRef.current);
    };
  }, []);

  // Soft warning state for resetting chat room history
  const [showResetConfirm, setShowResetConfirm] = useState(false);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isTypingSimulated]);

  const activeChannel = channels.find(c => c.id === activeChannelId) || channels[1];
  const activeChannelMessages = messages.filter(m => m.channelId === activeChannelId);

  // Dynamic extraction computation for active channel media links & resources
  const mediaFiles = messages
    .filter(m => m.channelId === activeChannelId && m.attachment && m.attachment.type === "image")
    .map(m => ({
      id: m.id,
      title: m.attachment!.name,
      size: m.attachment!.size,
      sender: m.senderName,
      timestamp: m.timestamp,
      url: m.attachment!.url || "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=400&auto=format&fit=crop"
    }));

  const docFiles = messages
    .filter(m => m.channelId === activeChannelId && m.attachment && m.attachment.type === "pdf")
    .map(m => ({
      id: m.id,
      title: m.attachment!.name,
      size: m.attachment!.size,
      sender: m.senderName,
      timestamp: m.timestamp
    }));

  const extractedLinks = (() => {
    const list: Array<{ id: string; url: string; title: string; sender: string; timestamp: string }> = [];
    messages.filter(m => m.channelId === activeChannelId).forEach(msg => {
      if (msg.attachment && msg.attachment.type === "link") {
        list.push({
          id: `${msg.id}-link-attachment`,
          url: "https://jeemain.nta.ac.in",
          title: msg.attachment.name,
          sender: msg.senderName,
          timestamp: msg.timestamp
        });
      }
      
      const urlRegex = /(https?:\/\/[^\s]+)/g;
      const matches = msg.content.match(urlRegex);
      if (matches) {
        matches.forEach((matchedUrl, idx) => {
          const cleanUrl = matchedUrl.replace(/[.,\/#!$%\^&\*;:{}=\-_`~()]/g, "");
          let labelName = "Study Resource Link";
          if (cleanUrl.includes("youtube.com") || cleanUrl.includes("youtu.be")) {
            labelName = "🔴 YouTube Lecture Clip";
          } else if (cleanUrl.includes("jeemain") || cleanUrl.includes("nta")) {
            labelName = "🎯 NTA JEE official portal";
          } else if (cleanUrl.includes("ca")) {
            labelName = "📚 ICAI Official Curriculum";
          }
          list.push({
            id: `${msg.id}-match-${idx}`,
            url: cleanUrl,
            title: labelName,
            sender: msg.senderName,
            timestamp: msg.timestamp
          });
        });
      }
    });
    return list;
  })();

  // Attachment upload simulator
  const handleSimulatedAttachment = (type: "pdf" | "image" | "link") => {
    let attachmentObj: Attachment;
    if (type === "pdf") {
      attachmentObj = {
        name: "Rotational_Mechanics_Summary_Sheet.pdf",
        size: "1.2 MB",
        type: "pdf"
      };
    } else if (type === "image") {
      attachmentObj = {
        name: "Kepler_Third_Law_Derivation.jpg",
        size: "820 KB",
        type: "image"
      };
    } else {
      attachmentObj = {
        name: "Interactive Saarthi Solver Doubt link",
        size: "View Link",
        type: "link"
      };
    }

    setSelectedAttachment(attachmentObj);
    setShowAttachmentMenu(false);
  };

  // Real offline files upload
  const handleRealFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const isImg = file.type.startsWith("image/");
      setSelectedAttachment({
        name: file.name,
        size: `${(file.size / (1024 * 1024)).toFixed(1)} MB`,
        type: isImg ? "image" : "pdf"
      });
    }
    setShowAttachmentMenu(false);
  };

  const handleSendMessage = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputText.trim() && !selectedAttachment) return;

    // Standard authorization rule bypass
    if (activeChannel.readOnlyForStudents && currentUserRole === "Student") {
      showChatToast("This channel is read-only. Only Teachers and Admins can publish announcements!");
      return;
    }

    const newMsg: Message = {
      id: `m-${Date.now()}`,
      senderName: currentUserRole === "Teacher" ? "Kunal Verma" : "Aman Sharma",
      role: currentUserRole,
      content: inputText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      avatarUrl: currentUserRole === "Teacher" 
        ? "https://lh3.googleusercontent.com/aida-public/AB6AXuBrvWwbdj5qPcyoAy4oUhKkWTjXmDsn-8qNR60EIxdSYvagG8RAgNTnKtl-RD2UPjm7Jc5fyMKjNdkI9VVldhWO-EAqfoCd6ug9MgonULT0U0UF7Wh1pqb88Qb5KD_uKbeZuBfWLWlBfFL6JTx860DJQkByUIddpXme1_ng1oOD05KeeiDr_S84ouHXvnzUEo_Uq0aYtnoyjyZfJ6yXDMnsN8UON0t0Sc0K6e4-G0hzQCzA84wx5xaGw0osc_xzOaUky14tkWgBW-4"
        : undefined,
      attachment: selectedAttachment || undefined,
      channelId: activeChannelId
    };

    setMessages(prev => [...prev, newMsg]);
    setInputText("");
    setSelectedAttachment(null);
    
    // Trigger callback to progress the dashboard statistics
    if (onActivityPerformed) {
      onActivityPerformed();
    }

    // If student talking in general discussion, simulate a highly interactive peer response
    if (activeChannelId === "discussion" && currentUserRole === "Student") {
      triggerSimulatedResponse("Teacher");
    } else if (activeChannelId === "discussion" && currentUserRole === "Teacher") {
      triggerSimulatedResponse("Student");
    }
  };

  const triggerSimulatedResponse = (responderRole: "Teacher" | "Student") => {
    setIsTypingSimulated(true);

    if (chatSimTimeoutRef.current) clearTimeout(chatSimTimeoutRef.current);

    chatSimTimeoutRef.current = setTimeout(() => {
      setIsTypingSimulated(false);
      let simulatedMsg: Message;
      
      if (responderRole === "Teacher") {
        simulatedMsg = {
          id: `sim-${Date.now()}`,
          senderName: "Kunal Verma",
          role: "Teacher",
          content: "Excellent discussion points! Remember to also review the Kepler shortcuts in Saarthi AI. I will upload our solved homework registry by today evening in the *Notes & PDFs* stream.",
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          avatarUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuBrvWwbdj5qPcyoAy4oUhKkWTjXmDsn-8qNR60EIxdSYvagG8RAgNTnKtl-RD2UPjm7Jc5fyMKjNdkI9VVldhWO-EAqfoCd6ug9MgonULT0U0UF7Wh1pqb88Qb5KD_uKbeZuBfWLWlBfFL6JTx860DJQkByUIddpXme1_ng1oOD05KeeiDr_S84ouHXvnzUEo_Uq0aYtnoyjyZfJ6yXDMnsN8UON0t0Sc0K6e4-G0hzQCzA84wx5xaGw0osc_xzOaUky14tkWgBW-4",
          channelId: "discussion"
        };
      } else {
        const studentNames = ["Aman Sharma", "Riya Jha", "Vikram Seth"];
        const selectedStudent = studentNames[Math.floor(Math.random() * studentNames.length)];
        simulatedMsg = {
          id: `sim-${Date.now()}`,
          senderName: selectedStudent,
          role: "Student",
          content: "Acknowledged, Kunal Sir! We are revising our notes right now. Thanks for this amazing real-time communication platform! 🔥🎯",
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          channelId: "discussion"
        };
      }

      setMessages(prev => [...prev, simulatedMsg]);
      
      // Trigger callback to progress dashboard statistics
      if (onActivityPerformed) {
        onActivityPerformed();
      }
    }, 1800);
  };

  const handleClearMessages = () => {
    setShowResetConfirm(true);
  };

  const executeClearMessages = () => {
    setMessages([]);
    showChatToast("Chat history cleared. Active room state reset.");
  };

  return (
    <div className="bg-[#0f172a] rounded-2xl border border-slate-800 shadow-2xl overflow-hidden text-slate-100 flex flex-col md:flex-row h-[550px] md:h-[620px]" id="community-chatroom-container">
      
      {/* 1. SIDEBAR PANEL: Channel Selection & User Persona Swap */}
      <div className={`md:w-72 bg-slate-900 border-r border-slate-800 flex flex-col shrink-0 ${
        mobileActivePane === "chat" ? "hidden md:flex" : "flex w-full"
      }`} id="chat-channels-sidebar">
        
        {/* Sidebar Header */}
        <div className="p-4 border-b border-slate-800 bg-slate-950 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center font-bold text-sm text-white shadow-md">
              👥
            </div>
            <div>
              <h2 className="font-extrabold text-sm tracking-tight text-white block">Sankalp Batch 2026</h2>
              <span className="text-[10px] text-slate-400 font-bold block">EduGrowth Premium Cohort</span>
            </div>
          </div>

          <button 
            onClick={handleClearMessages}
            title="Reset Chat history"
            className="p-1.5 text-slate-400 hover:text-red-400 rounded-lg hover:bg-slate-800 transition"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Channels List */}
        <div className="flex-1 overflow-y-auto p-3 space-y-3">
          <div>
            <span className="text-[9px] font-black text-slate-500 uppercase tracking-widest px-2.5 block mb-1.5">
              Broadcast Channels
            </span>
            <div className="space-y-1">
              {channels.map(chan => {
                const isActive = activeChannelId === chan.id;
                return (
                  <button
                    key={chan.id}
                    onClick={() => {
                      setActiveChannelId(chan.id);
                      setMobileActivePane("chat");
                    }}
                    className={`w-full text-left px-3 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-between ${
                      isActive 
                        ? "bg-slate-800 text-indigo-400 border border-slate-705 shadow-inner" 
                        : "hover:bg-slate-850 text-slate-300"
                    }`}
                  >
                    <div className="flex items-center gap-2 truncate">
                      <span className="text-sm shrink-0">{chan.icon}</span>
                      <span className="truncate">{chan.name}</span>
                    </div>
                    {chan.readOnlyForStudents && (
                      <span className="text-[8px] bg-red-950 text-red-400 px-1.5 py-0.2 rounded font-black border border-red-900 shrink-0">
                        ADMIN
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* User Persona Switcher */}
          <div className="pt-4 border-t border-slate-800">
            <span className="text-[9px] font-black text-slate-500 uppercase tracking-widest px-2.5 block mb-1.5">
              Test Identity Persona (Role Swap)
            </span>
            <div className="bg-slate-950 p-2 rounded-xl border border-slate-800 space-y-1">
              <button
                onClick={() => setCurrentUserRole("Teacher")}
                className={`w-full py-1.5 px-2 rounded-lg text-[11px] font-bold text-left flex items-center justify-between transition ${
                  currentUserRole === "Teacher" 
                    ? "bg-indigo-600/20 text-indigo-300 border border-indigo-900" 
                    : "text-slate-400 hover:text-white"
                }`}
              >
                <div className="flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-red-400"></span>
                  <span>Kunal (Teacher)</span>
                </div>
                {currentUserRole === "Teacher" && <Check className="w-3 h-3 text-indigo-400" />}
              </button>
              
              <button
                onClick={() => setCurrentUserRole("Student")}
                className={`w-full py-1.5 px-2 rounded-lg text-[11px] font-bold text-left flex items-center justify-between transition ${
                  currentUserRole === "Student" 
                    ? "bg-indigo-600/20 text-indigo-300 border border-indigo-900" 
                    : "text-slate-400 hover:text-white"
                }`}
              >
                <div className="flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#10b981]"></span>
                  <span>Aman (Student)</span>
                </div>
                {currentUserRole === "Student" && <Check className="w-3 h-3 text-indigo-400" />}
              </button>
            </div>
          </div>

          {/* Channel Description Guidelines */}
          <div className="p-3 bg-slate-950/40 rounded-xl border border-slate-800/40 space-y-1.5">
            <strong className="text-[10px] text-slate-400 uppercase tracking-wider block">Channel Info</strong>
            <p className="text-[10.5px] text-slate-500 leading-relaxed font-medium">
              {activeChannel.description}
            </p>
          </div>
        </div>

        {/* Assigned batch summary footer */}
        <div className="p-3 border-t border-slate-800 bg-slate-950 text-slate-400 flex items-center justify-between text-[11px]">
          <span className="flex items-center gap-1">
            <Users className="w-3.5 h-3.5 text-indigo-400" />
            <strong className="font-bold text-slate-200">128 Students</strong> Online
          </span>
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
        </div>
      </div>

      {/* 2. MAIN ACTIVE WINDOW: Conversational Header, Message Feed & Input Bar */}
      <div className={`flex-1 bg-slate-950 flex flex-col min-w-0 ${
        mobileActivePane === "sidebar" ? "hidden md:flex" : "flex"
      }`} id="active-community-chat-feed">
        
        {/* Chat window Header */}
        <div className="bg-slate-900 px-4 py-3 border-b border-slate-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5 min-w-0">
            {/* Mobile Back Button to navigate to sidebar */}
            <button
              onClick={() => setMobileActivePane("sidebar")}
              className="md:hidden p-1.5 text-slate-400 hover:text-white bg-slate-800 rounded-lg"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            
            <div className="truncate">
              <h3 className="font-extrabold text-[#818cf8] text-sm md:text-base flex items-center gap-1.5">
                <span>{activeChannel.icon}</span> 
                <span className="text-white truncate">{activeChannel.name}</span>
              </h3>
              <p className="text-[11px] text-slate-400 truncate max-w-[200px] md:max-w-md font-medium mt-0.5">
                {activeChannel.description}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <div className="hidden lg:flex text-[9.5px] bg-slate-800/80 text-slate-300 font-extrabold px-2.5 py-1 rounded-md border border-slate-700/60 uppercase tracking-widest">
              Role: {currentUserRole === "Teacher" ? "🔴 Instructor" : "🟢 Student"}
            </div>
            
            {activeChannel.readOnlyForStudents && (
              <span className="text-[9.5px] bg-red-950/80 text-red-300 border border-red-900 border-dashed rounded px-2 py-0.5 font-bold">
                ReadOnly
              </span>
            )}

            <button
              onClick={() => setIsMediaDrawerOpen(!isMediaDrawerOpen)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold border transition-all active:scale-95 ${
                isMediaDrawerOpen 
                  ? "bg-indigo-600 border-indigo-400 text-white shadow-md shadow-indigo-600/20" 
                  : "bg-slate-800 hover:bg-slate-700 border-slate-700 text-indigo-300"
              }`}
              title="View Channel Media, Documents & Links"
              id="view-channel-media-btn"
            >
              <FileText className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">View Channel Media</span>
              <span className="sm:hidden block">Media</span>
            </button>
          </div>
        </div>

        {/* Scrollable chat body */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-[#0b0f19]" id="active-channel-feed-viewport">
          {activeChannelMessages.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-8 text-slate-500 space-y-2">
              <div className="w-12 h-12 bg-slate-900 rounded-2xl flex items-center justify-center text-xl">📄</div>
              <p className="text-xs font-bold uppercase tracking-wider">No active messages in this channel.</p>
              <p className="text-[11px] text-slate-600 max-w-xs leading-relaxed">Be the first to publish notifications, study sheets or discussion queries!</p>
            </div>
          ) : (
            <div className="space-y-4">
              {activeChannelMessages.map((msg) => {
                const isInstructor = msg.role === "Teacher";
                const isSentByMe = (currentUserRole === "Teacher" && isInstructor) || (currentUserRole === "Student" && !isInstructor);

                return (
                  <div 
                    key={msg.id}
                    className="flex items-start gap-3 group animate-slide-up"
                    id={`chat-msg-${msg.id}`}
                  >
                    {/* User profile avatar / letter placeholder */}
                    {msg.avatarUrl ? (
                      <div className="w-9 h-9 rounded-xl overflow-hidden shrink-0 border border-slate-700">
                        <img src={msg.avatarUrl} alt={msg.senderName} className="w-full h-full object-cover" />
                      </div>
                    ) : (
                      <div className={`w-9 h-9 rounded-xl shrink-0 font-black text-xs flex items-center justify-center border ${
                        isInstructor 
                          ? "bg-red-950/80 border-red-700 text-red-300" 
                          : "bg-indigo-950 border-indigo-700 text-indigo-300"
                      }`}>
                        {msg.senderName.charAt(0)}
                      </div>
                    )}

                    {/* Message Bubble box panel */}
                    <div className="flex-1 bg-slate-900/65 border border-slate-800/80 rounded-2xl p-3 max-w-[85%] space-y-1.5 shadow-3xs">
                      
                      {/* Name, Role tag and timestamp */}
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="text-xs font-extrabold text-white">{msg.senderName}</span>
                        {isInstructor ? (
                          <span className="text-[8.5px] bg-red-950 text-red-400 px-1.5 py-0.2 rounded font-black border border-red-900 uppercase tracking-widest">
                            Teacher
                          </span>
                        ) : (
                          <span className="text-[8.5px] bg-indigo-950 text-indigo-400 px-1.5 py-0.2 rounded font-black border border-indigo-900 uppercase tracking-widest">
                            Student
                          </span>
                        )}
                        <span className="text-[10px] text-slate-500 font-bold ml-auto">{msg.timestamp}</span>
                      </div>

                      {/* Content block */}
                      <div className="text-slate-200 text-xs md:text-sm font-medium leading-relaxed whitespace-pre-wrap select-text">
                        {msg.content}
                      </div>

                      {/* Render inline attachment note if registered */}
                      {msg.attachment && (
                        <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800/80 flex items-center justify-between gap-3 mt-2">
                          <div className="flex items-center gap-2.5 min-w-0">
                            {msg.attachment.type === "pdf" && (
                              <div className="w-8 h-8 rounded-lg bg-red-950/80 border border-red-900 flex items-center justify-center text-red-400 shrink-0">
                                <FileText className="w-4 h-4" />
                              </div>
                            )}
                            {msg.attachment.type === "image" && (
                              <div className="w-8 h-8 rounded-lg bg-indigo-950 border border-indigo-900 flex items-center justify-center text-indigo-400 shrink-0">
                                <Image className="w-4 h-4" />
                              </div>
                            )}
                            {msg.attachment.type === "link" && (
                              <div className="w-8 h-8 rounded-lg bg-amber-950 border border-amber-900 flex items-center justify-center text-amber-400 shrink-0">
                                <Globe className="w-4 h-4" />
                              </div>
                            )}

                            <div className="truncate">
                              <span className="text-slate-100 font-bold block text-xs truncate max-w-[150px] md:max-w-md">
                                {msg.attachment.name}
                              </span>
                              <span className="text-[9.5px] text-slate-400 block font-semibold">{msg.attachment.size}</span>
                            </div>
                          </div>

                          <button 
                            type="button"
                            onClick={() => showChatToast(`Starting simulated download of: ${msg.attachment?.name || "attachment"}`)}
                            className="bg-slate-800 hover:bg-slate-705 text-slate-300 hover:text-white border border-slate-750 px-2.5 py-1 rounded-lg text-[10px] font-black transition-all active:scale-95"
                          >
                            Download
                          </button>
                        </div>
                      )}

                    </div>
                  </div>
                );
              })}

              {/* simulated typing bubbles */}
              {isTypingSimulated && (
                <div className="flex items-start gap-3 animate-pulse">
                  <div className="w-9 h-9 rounded-xl bg-indigo-950 border border-indigo-900 flex items-center justify-center text-xs font-black text-indigo-400">
                    ...
                  </div>
                  
                  <div className="bg-slate-900 border border-slate-800/80 rounded-2xl p-3 flex items-center gap-2.5">
                    <span className="w-2.5 h-2.5 bg-indigo-500 rounded-full animate-bounce [animation-delay:-0.3s]"></span>
                    <span className="w-2.5 h-2.5 bg-indigo-500 rounded-full animate-bounce [animation-delay:-0.15s]"></span>
                    <span className="w-2.5 h-2.5 bg-indigo-500 rounded-full animate-bounce"></span>
                    <span className="text-xs font-extrabold text-slate-400">Member typing live reply...</span>
                  </div>
                </div>
              )}

              <div ref={messagesEndRef} />
            </div>
          )}
        </div>

        {/* Selected Attachment Preview Bar */}
        {selectedAttachment && (
          <div className="bg-slate-900/90 border-t border-slate-800/80 px-4 py-2 flex items-center justify-between gap-3 shrink-0">
            <div className="flex items-center gap-2 min-w-0">
              <span className="text-xs bg-indigo-500 text-white font-extrabold rounded-md px-1.5 py-0.5 uppercase shrink-0">
                {selectedAttachment.type} Attach
              </span>
              <span className="text-[11.5px] text-slate-200 font-bold truncate max-w-[180px] md:max-w-md">
                {selectedAttachment.name} ({selectedAttachment.size})
              </span>
            </div>
            
            <button 
              onClick={() => setSelectedAttachment(null)}
              className="text-xs text-rose-400 hover:text-rose-300 font-black px-2 py-0.5 rounded-md hover:bg-rose-950/20"
            >
              De-select
            </button>
          </div>
        )}

        {/* Message Input container */}
        <div className="p-3 bg-slate-900 border-t border-slate-800 shrink-0">
          {activeChannel.readOnlyForStudents && currentUserRole === "Student" ? (
            <div className="bg-slate-950/80 border border-red-950 text-red-400/90 px-3 py-3 rounded-xl text-center text-xs font-semibold flex items-center justify-center gap-1.5">
              <AlertCircle className="w-4 h-4 shrink-0 text-red-500" />
              <span>Sankalp Batch Announcement rules: Only teachers can post here. Switch Identity to "Teacher" on the left to write!</span>
            </div>
          ) : (
            <form onSubmit={handleSendMessage} className="flex items-center gap-2 relative">
              
              {/* Secret hidden upload channel */}
              <input 
                type="file" 
                ref={fileInputRef} 
                onChange={handleRealFileUpload} 
                className="hidden" 
              />

              {/* Attachment Picker launcher button */}
              <div className="relative">
                <button
                  type="button"
                  onClick={() => setShowAttachmentMenu(!showAttachmentMenu)}
                  title="Attach asset or notes"
                  className={`p-3 rounded-xl bg-slate-800 hover:bg-slate-700/80 border text-slate-300 hover:text-white transition-all active:scale-95 flex items-center justify-center shrink-0 ${
                    showAttachmentMenu ? "border-indigo-500 text-indigo-400" : "border-slate-750"
                  }`}
                >
                  <Paperclip className="w-4 h-4" />
                </button>

                {/* Attachment Dropdown Panel */}
                {showAttachmentMenu && (
                  <div className="absolute bottom-14 left-0 w-52 bg-slate-900 border border-slate-850 p-2.5 rounded-xl shadow-2xl z-20 space-y-1 block animate-fade-in" id="attachment-dropdown">
                    <span className="text-[8.5px] font-black text-indigo-400 uppercase tracking-widest block px-1.5 mb-1">
                      Choose Attachment
                    </span>
                    
                    <button
                      type="button"
                      onClick={() => handleSimulatedAttachment("pdf")}
                      className="w-full text-left p-2 hover:bg-slate-800 rounded-lg text-xs font-bold transition flex items-center gap-2"
                    >
                      <FileText className="w-3.5 h-3.5 text-red-400" />
                      <span>Simulate PDF Sheet</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => handleSimulatedAttachment("image")}
                      className="w-full text-left p-2 hover:bg-slate-800 rounded-lg text-xs font-bold transition flex items-center gap-2"
                    >
                      <Image className="w-3.5 h-3.5 text-indigo-400" />
                      <span>Simulate Board JPG</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => handleSimulatedAttachment("link")}
                      className="w-full text-left p-2 hover:bg-slate-800 rounded-lg text-xs font-bold transition flex items-center gap-2"
                    >
                      <Globe className="w-3.5 h-3.5 text-amber-400" />
                      <span>Simulate Saarthi Link</span>
                    </button>

                    <div className="border-t border-slate-800 my-1 pt-1">
                      <button
                        type="button"
                        onClick={() => fileInputRef.current?.click()}
                        className="w-full text-left p-2 hover:bg-indigo-900/60 bg-indigo-950/20 text-indigo-300 rounded-lg text-[11px] font-bold transition flex items-center gap-1.5"
                      >
                        <Layers className="w-3.5 h-3.5" />
                        <span>Upload Real File</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>

              {/* Chat Text Input field */}
              <input
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder={`Send message to #${activeChannel.name}...`}
                className="flex-1 bg-slate-800 border border-slate-750/80 rounded-xl px-4 py-3 text-xs md:text-sm text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/30 focus:border-indigo-500 transition-all font-semibold"
              />

              {/* Send Button */}
              <button
                type="submit"
                className="bg-indigo-600 hover:bg-indigo-700 text-white p-3 rounded-xl font-bold transition-all active:scale-95 flex items-center justify-center shrink-0 shadow-md"
              >
                <Send className="w-4 h-4 fill-white" />
              </button>

            </form>
          )}
        </div>

      </div>

      {/* 3. RIGHT DRAWER PANEL: Channel Media, Documents & Links */}
      {isMediaDrawerOpen && (
        <div className="w-full md:w-80 bg-[#0c1221]/95 backdrop-blur-lg border-l border-slate-800/80 flex flex-col shrink-0 h-full animate-slide-left z-20" id="media-resources-drawer">
          
          {/* Drawer Header */}
          <div className="p-4.5 border-b border-rose-500/10 bg-slate-950/70 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-base text-indigo-400">📁</span>
              <div>
                <span className="font-extrabold text-sm tracking-tight text-white block">Media & Resource Hub</span>
                <span className="text-[9px] font-black text-rose-400 uppercase tracking-widest block">Batch Resources</span>
              </div>
            </div>
            
            <button 
              onClick={() => setIsMediaDrawerOpen(false)}
              className="p-1.5 text-slate-400 hover:text-white rounded-full bg-slate-900 border border-slate-800 hover:border-slate-700 hover:scale-105 transition-all cursor-pointer"
              title="Close Panel"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Tab Selector Buttons */}
          <div className="grid grid-cols-3 gap-1 p-2 bg-[#080d1a] border-b border-slate-900">
            <button
              onClick={() => setDrawerActiveTab("media")}
              className={`py-2 rounded-lg text-[10px] font-black uppercase tracking-wide text-center transition-all ${
                drawerActiveTab === "media"
                  ? "bg-indigo-600/30 text-indigo-300 border border-indigo-500/30 shadow-xs"
                  : "text-slate-400 hover:text-white hover:bg-slate-900/40"
              }`}
            >
              🖼️ Media
            </button>
            <button
              onClick={() => setDrawerActiveTab("docs")}
              className={`py-2 rounded-lg text-[10px] font-black uppercase tracking-wide text-center transition-all ${
                drawerActiveTab === "docs"
                  ? "bg-indigo-600/30 text-pink-400 border border-indigo-500/30 shadow-xs"
                  : "text-slate-400 hover:text-white hover:bg-slate-900/40"
              }`}
            >
              📄 Docs
            </button>
            <button
              onClick={() => setDrawerActiveTab("links")}
              className={`py-2 rounded-lg text-[10px] font-black uppercase tracking-wide text-center transition-all ${
                drawerActiveTab === "links"
                  ? "bg-indigo-600/30 text-amber-400 border border-indigo-500/30 shadow-xs"
                  : "text-slate-400 hover:text-white hover:bg-slate-900/40"
              }`}
            >
              🔗 Links
            </button>
          </div>

          {/* Tab Viewport */}
          <div className="flex-1 overflow-y-auto p-4.5 space-y-4">
            
            {/* Tab: Media Grid */}
            {drawerActiveTab === "media" && (
              <div className="space-y-3.5" id="drawer-media-section">
                <div className="flex items-center justify-between text-[9px] text-slate-400 uppercase tracking-widest font-black px-1">
                  <span>SHARED GALLERIES ({mediaFiles.length})</span>
                  <span className="text-indigo-400 font-extrabold">#{activeChannel.name}</span>
                </div>

                {mediaFiles.length === 0 ? (
                  <div className="text-center py-12 px-4 text-slate-500 space-y-2 bg-slate-950/45 rounded-2xl border border-slate-900 shadow-inner">
                    <span className="text-3xl block">🖼️</span>
                    <p className="text-[10px] font-black uppercase tracking-wider text-slate-300">No images shared yet</p>
                    <p className="text-[10.5px] text-slate-500 leading-relaxed font-bold">Image attachments shared in community channels will pop up here instantly.</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-2 gap-2.5" id="media-grid-view">
                    {mediaFiles.map((m) => (
                      <div 
                        key={m.id} 
                        className="group relative bg-[#070b13] rounded-xl overflow-hidden border border-slate-900 hover:border-indigo-500/40 shadow-sm hover:shadow-indigo-500/10 transition-all duration-300 cursor-pointer aspect-square"
                        onClick={() => showChatToast(`Inspecting thumb: ${m.title} (${m.size}) shared by ${m.sender}`)}
                      >
                        <img 
                          src={m.url} 
                          alt={m.title} 
                          className="w-full h-full object-cover group-hover:scale-108 transition-transform duration-500"
                          referrerPolicy="no-referrer"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-2 px-2.5">
                          <span className="text-[10px] font-extrabold text-white truncate block">{m.title}</span>
                          <span className="text-[8px] text-indigo-300 block font-bold uppercase tracking-wider">{m.size} • by {m.sender}</span>
                        </div>
                        {/* Always visible small tag for thumbnails */}
                        <div className="absolute top-1.5 right-1.5 px-1.5 py-0.5 rounded-md bg-black/60 text-[8px] text-slate-200 font-extrabold">
                          IMG
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Tab: Documents searchable List */}
            {drawerActiveTab === "docs" && (
              <div className="space-y-3.5" id="drawer-docs-section">
                {/* Search Bar */}
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-slate-500">
                    <Search className="w-3.5 h-3.5" />
                  </span>
                  <input
                    type="text"
                    value={docSearchQuery}
                    onChange={(e) => setDocSearchQuery(e.target.value)}
                    placeholder="Search shared booklets, DPP notes..."
                    className="w-full bg-slate-950/70 border border-slate-900 rounded-xl pl-9 pr-3.5 py-2.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-indigo-500 transition-all font-semibold"
                  />
                </div>

                <div className="flex items-center justify-between text-[9px] text-slate-400 uppercase tracking-widest font-black px-1">
                  <span>Shared Documents ({docFiles.length})</span>
                  <span className="text-pink-400 font-extrabold">Study Vault</span>
                </div>

                {(() => {
                  const filtered = docFiles.filter(d => d.title.toLowerCase().includes(docSearchQuery.toLowerCase()));
                  
                  if (filtered.length === 0) {
                    return (
                      <div className="text-center py-12 px-4 text-slate-500 space-y-2 bg-slate-950/45 rounded-2xl border border-slate-900 shadow-inner">
                        <span className="text-3xl block">📋</span>
                        <p className="text-[10px] font-black uppercase tracking-wider text-slate-300">No booklets found</p>
                        <p className="text-[10.5px] text-slate-500 leading-relaxed font-bold">Upload simulated study materials in the main input field to view documents.</p>
                      </div>
                    );
                  }

                  return (
                    <div className="space-y-2.5" id="docs-list-view">
                      {filtered.map((doc) => (
                        <div 
                          key={doc.id}
                          className="group bg-slate-950/80 hover:bg-[#131b2e]/90 p-3 rounded-xl border border-slate-900 hover:border-indigo-400/40 transition-all duration-350 flex items-center justify-between gap-3"
                        >
                          <div className="flex items-center gap-2.5 min-w-0">
                            {/* Premium Rounded Red PDF Icon Box */}
                            <div className="w-8.5 h-8.5 bg-red-950/70 border border-red-900/60 rounded-xl flex flex-col items-center justify-center shrink-0">
                              <span className="text-[7.5px] font-black text-rose-400 tracking-tighter leading-none mb-0.5">PDF</span>
                              <FileText className="w-3.5 h-3.5 text-rose-500" />
                            </div>
                            <div className="truncate min-w-0">
                              <span className="text-xs font-black text-slate-100 block truncate group-hover:text-indigo-300 transition-colors" title={doc.title}>
                                {doc.title}
                              </span>
                              <span className="text-[8px] text-slate-400 font-bold uppercase tracking-wider block mt-0.5">
                                {doc.size} • by {doc.sender}
                              </span>
                            </div>
                          </div>

                          <button
                            onClick={() => showChatToast(`Starting simulated download/preview of PDF booklet: ${doc.title}`)}
                            title="Download document PDF"
                            className="p-2 bg-slate-900 hover:bg-rose-950/30 text-slate-400 hover:text-rose-400 border border-slate-850 rounded-lg transition-all scale-95 group-hover:scale-100 cursor-pointer shadow-xs active:scale-95"
                          >
                            <Download className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ))}
                    </div>
                  );
                })()}

              </div>
            )}

            {/* Tab: Useful Links */}
            {drawerActiveTab === "links" && (
              <div className="space-y-3.5" id="drawer-links-section">
                <div className="flex items-center justify-between text-[9px] text-slate-400 uppercase tracking-widest font-black px-1">
                  <span>URL References ({extractedLinks.length})</span>
                  <span className="text-amber-400 font-extrabold">External Links</span>
                </div>

                {extractedLinks.length === 0 ? (
                  <div className="text-center py-12 px-4 text-slate-500 space-y-2 bg-slate-950/45 rounded-2xl border border-slate-900 shadow-inner">
                    <span className="text-3xl block">🌐</span>
                    <p className="text-[10px] font-black uppercase tracking-wider text-slate-300">No reference links parsed</p>
                    <p className="text-[10.5px] text-slate-500 leading-relaxed font-bold">Write or share references URL link like NTA result links to view references here.</p>
                  </div>
                ) : (
                  <div className="space-y-2.5">
                    {extractedLinks.map((link) => (
                      <div 
                        key={link.id}
                        className="bg-slate-950 p-3 rounded-xl border border-slate-900 hover:border-amber-500/40 transition-all flex items-center justify-between gap-3"
                      >
                        <div className="min-w-0 flex-1 space-y-0.5">
                          <span className="text-[11.5px] font-extrabold text-slate-200 block truncate leading-tight">
                            {link.title}
                          </span>
                          <span className="text-[9px] text-indigo-400 block font-semibold truncate hover:underline">
                            {link.url}
                          </span>
                          <span className="text-[8.5px] text-slate-500 block font-bold uppercase tracking-wider">
                            by {link.sender} • {link.timestamp}
                          </span>
                        </div>

                        <a 
                          href={link.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          title={`Navigate to ${link.url}`}
                          className="p-2 bg-slate-900 border border-slate-850 rounded-lg hover:bg-amber-950/20 text-slate-400 hover:text-amber-400 transition-colors shrink-0"
                        >
                          <ExternalLink className="w-3.5 h-3.5" />
                        </a>
                      </div>
                    ))}
                  </div>
                )}

              </div>
            )}

          </div>

          {/* Quick instructions indicator inside sidebar */}
          <div className="p-3 bg-slate-950 border-t border-slate-800 text-[10.5px] text-slate-400">
            <span className="block font-black text-slate-300 uppercase tracking-wide mb-0.5 text-[8.5px]">💡 Smart Sync Guide</span>
            <span>Attachments and external URLs shared in this chat channel are auto-rendered in these folders instantly.</span>
          </div>

        </div>
      )}

      {/* ====================================================
          CUSTOM SYSTEM CHAT TOAST OVERLAYS (No window.alert)
         ==================================================== */}
      {chatToast && (
        <div className="fixed top-20 right-5 z-60 animate-bounce max-w-xs bg-slate-950/95 border border-indigo-500/40 rounded-xl p-3.5 shadow-2xl flex items-center gap-2.5 backdrop-blur-md">
          <div className="w-2.5 h-2.5 rounded-full bg-indigo-500 animate-ping shrink-0" />
          <div className="text-[11px] font-semibold text-slate-200">
            {chatToast}
          </div>
          <button onClick={() => setChatToast(null)} className="w-5 h-5 text-slate-500 hover:text-white font-bold ml-1.5 p-0 bg-transparent border-0 hover:bg-slate-900 rounded flex items-center justify-center">
            ✕
          </button>
        </div>
      )}

      {/* ====================================================
          SOFT WARN RESET HISTORY CONFIRMATION DIALOG (No window.confirm)
         ==================================================== */}
      {showResetConfirm && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-60 flex items-center justify-center p-4">
          <div className="bg-[#0b101c]/95 border border-slate-800/80 rounded-2xl max-w-sm w-full p-6 shadow-2xl text-center space-y-4 backdrop-blur-md">
            <div className="w-11 h-11 rounded-full bg-amber-950/40 border border-amber-900/60 flex items-center justify-center mx-auto text-amber-400 text-lg">
              ⚠️
            </div>
            <div>
              <h3 className="font-extrabold text-xs text-white uppercase tracking-wider">Reset Batch Chat Logs?</h3>
              <p className="text-[11px] text-slate-400 mt-2 leading-relaxed">
                Confirm resetting active chat channels and purging local messaging timelines. This action clears current session buffers.
              </p>
            </div>
            <div className="flex items-center gap-3.5 pt-1.5">
              <button 
                onClick={() => setShowResetConfirm(false)}
                className="flex-1 py-2 rounded-xl border border-slate-800 text-slate-400 hover:text-white bg-transparent hover:bg-slate-900 transition-all text-[10px] font-black uppercase font-sans"
              >
                Cancel
              </button>
              <button 
                onClick={() => {
                  setShowResetConfirm(false);
                  executeClearMessages();
                }}
                className="flex-1 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-slate-955 transition-all text-[10px] font-black uppercase font-sans border-0"
              >
                Clear Room
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
