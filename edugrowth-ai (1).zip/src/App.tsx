import { useState, useEffect, lazy, Suspense } from "react";
import { 
  Menu, 
  LayoutDashboard, 
  UserPlus, 
  Users, 
  GraduationCap, 
  Settings as SettingsIcon, 
  Loader2,
  Sparkles,
  HelpCircle,
  ClipboardCheck,
  TrendingUp,
  Edit2
} from "lucide-react";
import { 
  FunnelChart, 
  Funnel, 
  LabelList, 
  Tooltip as RechartsTooltip, 
  ResponsiveContainer 
} from "recharts";

import { Lead, Student, Course, MessageTemplate } from "./types";

// Optimize initial bundle size by utilizing dynamic imports with React.lazy
const LeadsView = lazy(() => import("./components/LeadsView"));
const StudentsView = lazy(() => import("./components/StudentsView"));
const SettingsView = lazy(() => import("./components/SettingsView"));
const DoubtSolverView = lazy(() => import("./components/DoubtSolverView"));
const DPPPracticeView = lazy(() => import("./components/DPPPracticeView"));
const StudentPerformanceView = lazy(() => import("./components/StudentPerformanceView"));
const BatchChatView = lazy(() => import("./components/BatchChatView"));
const MyGrowthView = lazy(() => import("./components/MyGrowthView"));

export default function App() {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'leads' | 'students' | 'settings' | 'saarthi' | 'dpps' | 'performance' | 'stats' | 'chat' | 'growth'>('leads');
  
  // Routing parameters state
  const [routedDoubt, setRoutedDoubt] = useState<string>("");
  const [routedCourse, setRoutedCourse] = useState<string>("");
  const [routedTopic, setRoutedTopic] = useState<string>("");
  const [routedDifficulty, setRoutedDifficulty] = useState<string>("");

  const handleNavigateToTab = (tab: any, params?: any) => {
    let targetTab = tab;
    if (tab === 'doubt-solver') targetTab = 'saarthi';
    if (tab === 'dpp-quiz') targetTab = 'dpps';

    if ((tab === 'doubt-solver' || tab === 'saarthi') && params) {
      setRoutedDoubt(params.doubt || "");
      setRoutedCourse(params.course || "");
    }
    if ((tab === 'dpp-quiz' || tab === 'dpps') && params) {
      setRoutedTopic(params.topic || "");
      setRoutedDifficulty(params.difficulty || "");
    }
    setActiveTab(targetTab);
    setIsSidebarOpen(false);
  };
  
  // App data states
  const [leads, setLeads] = useState<Lead[]>([]);
  const [students, setStudents] = useState<Student[]>([]);
  const [courses, setCourses] = useState<Course[]>([]);
  const [templates, setTemplates] = useState<MessageTemplate[]>([]);
  
  // Interaction tracking state to dynamically progress the analytics funnel & conversion metric
  const [interactionCount, setInteractionCount] = useState<number>(() => {
    try {
      const saved = localStorage.getItem("edugrowth_interactions");
      return saved ? parseInt(saved, 10) : 0;
    } catch {
      return 0;
    }
  });

  const incrementInteractions = () => {
    setInteractionCount(prev => {
      const next = prev + 1;
      try {
        localStorage.setItem("edugrowth_interactions", next.toString());
      } catch (e) {}
      return next;
    });
  };
  
  const [isLoading, setIsLoading] = useState(true);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isMoreMenuOpen, setIsMoreMenuOpen] = useState(false);

  const [counselorName, setCounselorName] = useState<string>(() => {
    try {
      return localStorage.getItem("edugrowth_counselor_name") || "Kunal Verma";
    } catch {
      return "Kunal Verma";
    }
  });

  const [counselorTitle, setCounselorTitle] = useState<string>(() => {
    try {
      return localStorage.getItem("edugrowth_counselor_title") || "Senior admissions advisor";
    } catch {
      return "Senior admissions advisor";
    }
  });

  const [isEditProfileOpen, setIsEditProfileOpen] = useState(false);

  // Sync state functions
  const fetchLeads = async () => {
    try {
      const res = await fetch("/api/leads");
      if (res.ok) {
        const data = await res.json();
        setLeads(data);
      }
    } catch (err) {
      console.error("Error fetching leads:", err);
    }
  };

  const fetchStudents = async () => {
    try {
      const res = await fetch("/api/students");
      if (res.ok) {
        const data = await res.json();
        setStudents(data);
      }
    } catch (err) {
      console.error("Error fetching students:", err);
    }
  };

  const fetchCourses = async () => {
    try {
      const res = await fetch("/api/courses");
      if (res.ok) {
        const data = await res.json();
        setCourses(data);
      }
    } catch (err) {
      console.error("Error fetching courses:", err);
    }
  };

  const fetchTemplates = async () => {
    try {
      const res = await fetch("/api/templates");
      if (res.ok) {
        const data = await res.json();
        setTemplates(data);
      }
    } catch (err) {
      console.error("Error fetching templates:", err);
    }
  };

  const loadAllData = async () => {
    setIsLoading(true);
    await Promise.all([
      fetchLeads(),
      fetchStudents(),
      fetchCourses(),
      fetchTemplates()
    ]);
    setIsLoading(false);
  };

  useEffect(() => {
    loadAllData();
  }, []);

  return (
    <div className="flex flex-col md:flex-row h-screen bg-[#F8FAFC] text-[#141d23] font-sans overflow-hidden antialiased" id="app-root-shell">
      
      {/* ==========================================
          SIDEBAR NAVIGATION (RESPONSIVE DRAWERS)
         ========================================== */}
      <aside className={`fixed md:sticky md:top-0 top-0 left-0 bg-slate-900 text-slate-300 border-r border-[#1e293b] w-72 h-full md:h-screen z-40 transition-transform duration-300 flex flex-col shadow-xl md:translate-x-0 ${
        isSidebarOpen ? "translate-x-0" : "-translate-x-full"
      }`} id="desktop-sidebar-nav">
        <div className="p-6 border-b border-slate-800 flex items-center justify-between bg-slate-950">
          <div className="flex items-center space-x-3">
            <div className="h-9 w-9 rounded-xl bg-indigo-500 flex items-center justify-center text-white shadow-lg font-bold text-lg">⚡</div>
            <span className="font-bold text-xl text-white tracking-tight">EduGrowth <span className="text-indigo-400 font-light text-base">Pro</span></span>
          </div>
          {/* Close button for mobile drawer */}
          <button onClick={() => setIsSidebarOpen(false)} className="md:hidden text-slate-400 hover:text-white hover:scale-110 p-1">
            ✕
          </button>
        </div>
        
        <nav className="flex-1 p-5 space-y-1.5 overflow-y-auto">
          <div className="text-[11px] font-semibold text-slate-500 uppercase px-3 mb-2 tracking-widest">Workspace</div>
          
          <button 
            onClick={() => { setActiveTab('leads'); setIsSidebarOpen(false); }} 
            className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl text-sm font-medium transition-all ${
              activeTab === 'leads' ? 'bg-indigo-600 text-white shadow-md' : 'hover:bg-slate-800'
            }`}
          >
            <span>👥</span> <span>Admissions Hub</span>
          </button>

          <button 
            onClick={() => { setActiveTab('chat'); setIsSidebarOpen(false); }} 
            className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl text-sm font-medium transition-all ${
              activeTab === 'chat' ? 'bg-indigo-600 text-white shadow-md' : 'hover:bg-slate-800'
            }`}
          >
            <span>👥</span> <span>Batch ChatRoom</span>
          </button>

          <button 
            onClick={() => { setActiveTab('growth'); setIsSidebarOpen(false); }} 
            className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl text-sm font-medium transition-all ${
              activeTab === 'growth' ? 'bg-indigo-600 text-white shadow-md' : 'hover:bg-slate-800'
            }`}
          >
            <span>📊</span> <span>My Growth</span>
          </button>

          <button 
            onClick={() => { setActiveTab('performance'); setIsSidebarOpen(false); }} 
            className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl text-sm font-medium transition-all ${
              activeTab === 'performance' ? 'bg-indigo-600 text-white shadow-md' : 'hover:bg-slate-800'
            }`}
          >
            <span>📈</span> <span>Student Matrix</span>
          </button>

          <button 
            onClick={() => { setActiveTab('stats'); setIsSidebarOpen(false); }} 
            className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl text-sm font-medium transition-all ${
              activeTab === 'stats' ? 'bg-indigo-600 text-white shadow-md' : 'hover:bg-slate-800'
            }`}
          >
            <span>📊</span> <span>Analytics Funnel</span>
          </button>

          <button 
            onClick={() => { setActiveTab('saarthi'); setIsSidebarOpen(false); }} 
            className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl text-sm font-medium transition-all ${
              activeTab === 'saarthi' ? 'bg-indigo-600 text-white shadow-md' : 'hover:bg-slate-800'
            }`}
          >
            <span>🤖</span> <span>Saarthi AI</span>
          </button>

          <button 
            onClick={() => { setActiveTab('dpps'); setIsSidebarOpen(false); }} 
            className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl text-sm font-medium transition-all ${
              activeTab === 'dpps' ? 'bg-indigo-600 text-white shadow-md' : 'hover:bg-slate-800'
            }`}
          >
            <span>📝</span> <span>Micro-DPPs</span>
          </button>

          <div className="text-[11px] font-semibold text-slate-500 uppercase px-3 mt-4 mb-2 tracking-widest">Administration</div>

          <button 
            onClick={() => { setActiveTab('students'); setIsSidebarOpen(false); }} 
            className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl text-sm font-medium transition-all ${
              activeTab === 'students' ? 'bg-indigo-600 text-white shadow-md' : 'hover:bg-slate-800'
            }`}
          >
            <span>🎓</span> <span>Enrolled Students</span>
          </button>

          <button 
            onClick={() => { setActiveTab('settings'); setIsSidebarOpen(false); }} 
            className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl text-sm font-medium transition-all ${
              activeTab === 'settings' ? 'bg-indigo-600 text-white shadow-md' : 'hover:bg-slate-800'
            }`}
          >
            <span>⚙️</span> <span>Settings & Templates</span>
          </button>
        </nav>

        {/* Counselor Credit block at bottom of custom dark sidebar */}
        <div className="p-4 m-4 bg-slate-800/60 rounded-xl border border-slate-700/30 space-y-1 relative group" id="sidebar-counselor-credit">
          <div className="flex items-center justify-between">
            <span className="text-[9px] text-[#818cf8] font-bold block uppercase tracking-wider">Assigned Counselor</span>
            <button 
              onClick={() => setIsEditProfileOpen(true)}
              className="p-1 hover:bg-slate-700/60 rounded text-slate-400 hover:text-white transition-colors cursor-pointer"
              title="Edit Profile"
              id="btn-edit-counselor-profile"
            >
              <Edit2 className="w-3 h-3" />
            </button>
          </div>
          <strong className="text-xs text-white block">{counselorName}</strong>
          <span className="text-[10px] text-slate-400 block font-light">{counselorTitle}</span>
        </div>
      </aside>

      {/* ==========================================
          MAIN CONTENT AREA (SCROLLABLE & RESPONSIVE)
         ========================================== */}
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden pb-16 md:pb-0">
        
        {/* PREMIUM COMPACT HEADER */}
        <header className="bg-white border-b border-slate-200/80 px-4 py-3 md:px-8 md:py-4 flex items-center justify-between shadow-xs">
          <div className="flex items-center space-x-3">
            {/* Mobile menu trigger */}
            <button 
              onClick={() => setIsSidebarOpen(!isSidebarOpen)} 
              className="p-2 cursor-pointer text-[#4f6073] hover:bg-slate-100 transition-colors rounded-full md:hidden active:scale-95"
              aria-label="Toggle Side Drawers"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="flex items-center space-x-2">
              <div className="h-6 w-6 rounded-lg bg-indigo-600 flex items-center justify-center text-white font-bold text-xs">⚡</div>
              <span className="font-bold text-slate-950 tracking-tight text-sm md:text-lg">EduGrowth Pro</span>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="hidden sm:flex items-center gap-1.5 text-xs bg-[#ecf5fe] border border-[#d3e4fb] px-3 py-1.5 rounded-full text-[#4f6073] font-bold">
              <Sparkles className="w-3.5 h-3.5 text-red-500 animate-pulse" />
              <span>Kunal Verma (Admissions Advisor)</span>
            </div>

            <button 
              onClick={() => setActiveTab('settings')}
              className="h-9 w-9 rounded-full overflow-hidden border border-slate-200 cursor-pointer shadow-sm hover:scale-105 active:scale-95 transition-all bg-[#ffe6e4]"
            >
              <img 
                alt="User Advisor Avatar" 
                className="w-full h-full object-cover" 
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuBrvWwbdj5qPcyoAy4oUhKkWTjXmDsn-8qNR60EIxdSYvagG8RAgNTnKtl-RD2UPjm7Jc5fyMKjNdkI9VVldhWO-EAqfoCd6ug9MgonULT0U0UF7Wh1pqb88Qb5KD_uKbeZuBfWLWlBfFL6JTx860DJQkByUIddpXme1_ng1oOD05KeeiDr_S84ouHXvnzUEo_Uq0aYtnoyjyZfJ6yXDMnsN8UON0t0Sc0K6e4-G0hzQCzA84wx5xaGw0osc_xzOaUky14tkWgBW-4"
              />
            </button>
          </div>
        </header>

        {/* CONTAINER FOR SUMMARY CARDS (Always visible at the top, just like mockup!) */}
        <div className="px-4 py-4 md:px-8 bg-slate-950 border-b border-slate-800 grid grid-cols-2 lg:grid-cols-4 gap-3">
          <div className="glass-card neon-glow-blue p-3.5 rounded-xl border border-blue-500/10 flex flex-col justify-center">
            <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest block">Total Prospects</span>
            <div className="text-xl font-black text-blue-400 mt-1">{leads.length || 4}</div>
          </div>
          <div className="glass-card neon-glow-red p-3.5 rounded-xl border border-red-500/10 flex flex-col justify-center">
            <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest block">Hot Leads</span>
            <div className="text-xl font-black text-rose-500 mt-1">
              {leads.filter(l => l.status === "Hot").length || 2}
            </div>
          </div>
          <div className="glass-card neon-glow-emerald p-3.5 rounded-xl border border-emerald-500/10 flex flex-col justify-center">
            <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest block">Enrolled Students</span>
            <div className="text-xl font-black text-emerald-400 mt-1">{students.length || 2}</div>
          </div>
          <div className="glass-card neon-glow-amber p-3.5 rounded-xl border border-amber-500/10 flex flex-col justify-center">
            <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest block">Conversion Rate</span>
            <div className="text-xl font-black text-amber-400 mt-1">
              {(() => {
                const baseRate = leads.length > 0
                  ? Math.round((students.length / leads.length) * 100)
                  : 50;
                const finalRate = Math.min(100, baseRate + (interactionCount * 2));
                return `${finalRate}%`;
              })()}
            </div>
          </div>
        </div>

        {/* DYNAMIC SCROLLABLE TAB CONTENT WITH BUNDLE-SPLIT SUSPENSE DEFERRALS */}
        <div className="flex-1 overflow-y-auto p-4 md:p-8 space-y-6">
          {isLoading ? (
            <div className="h-64 flex flex-col items-center justify-center gap-2" id="app-main-loading-spinner">
              <Loader2 className="w-10 h-10 animate-spin text-indigo-600" />
              <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mt-2">Caching Prospects Registry...</p>
            </div>
          ) : (
            <Suspense fallback={
              <div className="h-64 flex flex-col items-center justify-center gap-2" id="app-lazy-view-loading-spinner">
                <Loader2 className="w-10 h-10 animate-spin text-indigo-600 animate-pulse" />
                <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mt-2 font-mono">Assembling Workspace View...</p>
              </div>
            }>
              <>
              {activeTab === 'leads' && (
                <div className="space-y-6">
                  <div className="flex justify-between items-center">
                    <div>
                      <h1 className="font-extrabold text-2xl md:text-3xl text-slate-850 tracking-tight">Student Admissions Pipeline</h1>
                      <p className="text-[#4f6073] text-sm mt-1">Manage, search, call, and convert your hottest educational leads.</p>
                    </div>
                  </div>
                  <LeadsView 
                    leads={leads} 
                    courses={courses} 
                    templates={templates} 
                    onRefreshLeads={fetchLeads} 
                    onRefreshStudents={fetchStudents}
                  />
                </div>
              )}
              
              {activeTab === 'performance' && (
                <div className="space-y-6">
                  <div>
                    <h1 className="font-extrabold text-2xl md:text-3xl text-slate-850 tracking-tight">Student Performance & Analytics</h1>
                    <p className="text-[#4f6073] text-sm mt-1">Real-time batch standings, test progression charts, and automated AI health nudges.</p>
                  </div>
                  <StudentPerformanceView 
                    onNavigateToTab={handleNavigateToTab}
                  />
                </div>
              )}

              {activeTab === 'stats' && (
                <div className="space-y-6">
                  <div>
                    <h1 className="font-extrabold text-2xl md:text-3xl text-slate-850 tracking-tight">Enrollment Funnel Analytics</h1>
                    <p className="text-[#4f6073] text-sm mt-1">A real-time display of recruitment stages, inquiry flow, and user onboarding conversions.</p>
                  </div>

                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    {/* Funnel Map */}
                    <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm lg:col-span-2 space-y-4">
                      <div>
                        <h3 className="font-bold text-base text-slate-800">Conversion Funnel Stages</h3>
                        <p className="text-xs text-slate-400">Visualization of candidate retention across admissions milestones.</p>
                      </div>
                      
                      <div className="w-full h-80 flex items-center justify-center">
                        <ResponsiveContainer width="100%" height="100%">
                           <FunnelChart>
                             <RechartsTooltip contentStyle={{ borderRadius: '8px' }} />
                             <Funnel
                               data={[
                                 { value: 100 + interactionCount * 2, name: 'Inquiries', fill: '#1E293B' },
                                 { value: 80 + interactionCount * 3, name: 'Contacted', fill: '#4F46E5' },
                                 { value: 50 + interactionCount * 4, name: 'Hot Stage', fill: '#3B82F6' },
                                 { value: 30 + interactionCount * 5, name: 'Admitted', fill: '#10B981' }
                               ]}
                               dataKey="value"
                             >
                               <LabelList position="right" fill="#475569" dataKey="name" fontSize={11} fontWeight="bold" />
                             </Funnel>
                           </FunnelChart>
                        </ResponsiveContainer>
                      </div>
                    </div>

                    {/* Quick Conversion insights */}
                    <div className="bg-gradient-to-br from-indigo-900 to-indigo-950 p-6 rounded-2xl text-white shadow-md flex flex-col justify-between">
                      <div className="space-y-4">
                        <span className="text-[10px] uppercase font-extrabold text-indigo-300 tracking-widest block font-sans">Cohort Milestones</span>
                        <h4 className="font-extrabold text-base">Key Dropout Audits</h4>
                        <p className="text-xs text-indigo-100/90 leading-relaxed font-sans">
                          Our funnel shows a <strong className="text-[#10B981]">{80 + interactionCount * 3} contacted prospects</strong>, and a solid <strong className="text-amber-400">{50 + interactionCount * 4} converted to Hot Lead status</strong>.
                        </p>
                        <p className="text-xs text-indigo-100/90 leading-relaxed font-sans">
                          The absolute final enrollment clearance stands at <strong className="text-green-400">{30 + interactionCount * 5}</strong> overall. Student community chat and Saarthi AI usage count has accumulated <strong className="text-pink-400">+{interactionCount * 2}% progress acceleration</strong> in real-time.
                        </p>
                      </div>

                      <div className="border-t border-indigo-800 pt-4 mt-6">
                        <button 
                          onClick={() => setActiveTab('leads')}
                          className="w-full text-center py-2.5 bg-white text-indigo-950 rounded-lg text-xs font-bold hover:bg-indigo-50 transition-all shadow-sm"
                        >
                          Convert Leads Now
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'saarthi' && (
                <div className="space-y-6">
                  <div>
                    <h1 className="font-extrabold text-2xl md:text-3xl text-slate-850 tracking-tight">EduGrowth Saarthi AI</h1>
                    <p className="text-[#4f6073] text-sm mt-1">Physics Wallah inspired empathetic doubt counselor workspace.</p>
                  </div>
                  <DoubtSolverView 
                    initialDoubt={routedDoubt}
                    initialCourse={routedCourse}
                    onClearInitialState={() => {
                      setRoutedDoubt("");
                      setRoutedCourse("");
                    }}
                    onActivityPerformed={incrementInteractions}
                  />
                </div>
              )}

              {activeTab === 'dpps' && (
                <div className="space-y-6">
                  <div>
                    <h1 className="font-extrabold text-2xl md:text-3xl text-slate-850 tracking-tight">AI Daily Practice Problems (DPP)</h1>
                    <p className="text-[#4f6073] text-sm mt-1">Generate dynamic 5-question mock sheets corresponding to latest 2026 exam trends.</p>
                  </div>
                  <DPPPracticeView 
                    initialTopic={routedTopic}
                    initialDifficulty={routedDifficulty}
                    onClearInitialState={() => {
                      setRoutedTopic("");
                      setRoutedDifficulty("");
                    }}
                  />
                </div>
              )}

              {activeTab === 'students' && (
                <div className="space-y-6">
                  <div>
                    <h1 className="font-extrabold text-2xl md:text-3xl text-slate-850 tracking-tight">Enrolled Students Ledger</h1>
                    <p className="text-[#4f6073] text-sm mt-1">Track onboarding checkpoints, fee payments, and batch schedules.</p>
                  </div>
                  <StudentsView 
                    students={students} 
                    courses={courses} 
                    onRefreshStudents={fetchStudents}
                  />
                </div>
              )}

              {activeTab === 'chat' && (
                <div className="space-y-6">
                  <div>
                    <h1 className="font-extrabold text-2xl md:text-3xl text-slate-850 tracking-tight">Batch Community Chat</h1>
                    <p className="text-[#4f6073] text-sm mt-1">Real-time collaborative workspace for batch discussions, study materials and announcements.</p>
                  </div>
                  <BatchChatView onActivityPerformed={incrementInteractions} />
                </div>
              )}

              {activeTab === 'growth' && (
                <div className="space-y-6">
                  <div>
                    <h1 className="font-extrabold text-2xl md:text-3xl text-slate-850 tracking-tight">My Growth Dashboard</h1>
                    <p className="text-[#4f6073] text-sm mt-1">Your customized, high-precision academic growth metrics and study badges.</p>
                  </div>
                  <MyGrowthView />
                </div>
              )}

              {activeTab === 'settings' && (
                <div className="space-y-6">
                  <div>
                    <h1 className="font-extrabold text-2xl md:text-3xl text-slate-850 tracking-tight">EduGrowth Settings & AI Customizer</h1>
                    <p className="text-[#4f6073] text-sm mt-1">Verify credentials, configure target courses, and customize default WhatsApp templates.</p>
                  </div>
                  <SettingsView 
                    courses={courses} 
                    templates={templates} 
                    onRefreshCourses={fetchCourses} 
                    onRefreshTemplates={fetchTemplates}
                  />
                </div>
              )}
              </>
            </Suspense>
          )}
        </div>
      </main>

      {/* ==========================================
          MOBILE-OPTIMIZED PRECISE FOOTER NAVIGATION
         ========================================== */}
      <footer className="md:hidden fixed bottom-0 left-0 right-0 bg-[#0b0f19]/90 backdrop-blur-md border-t border-slate-850 h-16 px-4 flex justify-around items-center z-50 shadow-[0_-4px_20px_rgba(0,0,0,0.5)]">
        <button 
          onClick={() => { setActiveTab('leads'); setIsMoreMenuOpen(false); }} 
          className={`flex flex-col items-center space-y-0.5 text-[9px] font-bold transition-all shrink-0 ${activeTab === 'leads' ? 'text-indigo-400 scale-105' : 'text-slate-400'}`}
        >
          <span className="text-lg">👥</span> <span>Leads</span>
        </button>
        <button 
          onClick={() => { setActiveTab('chat'); setIsMoreMenuOpen(false); }} 
          className={`flex flex-col items-center space-y-0.5 text-[9px] font-bold transition-all shrink-0 ${activeTab === 'chat' ? 'text-pink-400 scale-105' : 'text-slate-400'}`}
        >
          <span className="text-lg">💬</span> <span>Chat</span>
        </button>
        <button 
          onClick={() => { setActiveTab('growth'); setIsMoreMenuOpen(false); }} 
          className={`flex flex-col items-center space-y-0.5 text-[9px] font-bold transition-all shrink-0 ${activeTab === 'growth' ? 'text-emerald-400 scale-105' : 'text-slate-400'}`}
        >
          <span className="text-lg">📊</span> <span>Growth</span>
        </button>
        <button 
          onClick={() => { setActiveTab('saarthi'); setIsMoreMenuOpen(false); }} 
          className={`flex flex-col items-center space-y-0.5 text-[9px] font-bold transition-all shrink-0 ${activeTab === 'saarthi' ? 'text-amber-400 scale-105' : 'text-slate-400'}`}
        >
          <span className="text-lg">🤖</span> <span>Saarthi</span>
        </button>
        <button 
          onClick={() => setIsMoreMenuOpen(!isMoreMenuOpen)} 
          className={`flex flex-col items-center space-y-0.5 text-[9px] font-bold transition-all shrink-0 ${isMoreMenuOpen ? 'text-violet-400 scale-105' : 'text-slate-400'}`}
        >
          <span className="text-lg">🔮</span> <span>More</span>
        </button>
      </footer>

      {/* Dynamic Popup Menu for "More" on Mobile */}
      {isMoreMenuOpen && (
        <div className="md:hidden fixed bottom-18 left-4 right-4 bg-slate-950/95 backdrop-blur-md border border-slate-800 rounded-2xl p-4.5 z-55 shadow-2xl animate-slide-left text-white space-y-3.5" id="more-popup-menu">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <span className="text-[11px] font-black uppercase tracking-widest text-indigo-400">Additional Features</span>
            <button 
              onClick={() => setIsMoreMenuOpen(false)}
              className="text-slate-400 hover:text-white text-xs font-bold w-6 h-6 rounded-full flex items-center justify-center bg-slate-900 border border-slate-800"
            >
              ✕
            </button>
          </div>
          <div className="grid grid-cols-2 gap-2.5">
            <button 
              onClick={() => { setActiveTab('dpps'); setIsMoreMenuOpen(false); }}
              className={`p-3 rounded-xl border flex flex-col items-center justify-center gap-1.5 text-center transition-all ${
                activeTab === 'dpps' ? 'bg-indigo-650/40 border-indigo-500 text-indigo-300' : 'bg-slate-900/60 border-slate-800/80 text-slate-300 hover:bg-slate-800'
              }`}
            >
              <span className="text-xl">📝</span>
              <span className="text-[10px] font-black font-sans uppercase">Micro-DPPs</span>
            </button>

            <button 
              onClick={() => { setActiveTab('performance'); setIsMoreMenuOpen(false); }}
              className={`p-3 rounded-xl border flex flex-col items-center justify-center gap-1.5 text-center transition-all ${
                activeTab === 'performance' ? 'bg-indigo-650/40 border-indigo-500 text-indigo-300' : 'bg-slate-900/60 border-slate-800/80 text-slate-300 hover:bg-slate-800'
              }`}
            >
              <span className="text-xl">📈</span>
              <span className="text-[10px] font-black font-sans uppercase">Student Matrix</span>
            </button>

            <button 
              onClick={() => { setActiveTab('stats'); setIsMoreMenuOpen(false); }}
              className={`p-3 rounded-xl border flex flex-col items-center justify-center gap-1.5 text-center transition-all ${
                activeTab === 'stats' ? 'bg-indigo-650/40 border-indigo-500 text-indigo-300' : 'bg-slate-900/60 border-slate-800/80 text-slate-300 hover:bg-slate-800'
              }`}
            >
              <span className="text-xl">📊</span>
              <span className="text-[10px] font-black font-sans uppercase">Funnel Charts</span>
            </button>

            <button 
              onClick={() => { setActiveTab('settings'); setIsMoreMenuOpen(false); }}
              className={`p-3 rounded-xl border flex flex-col items-center justify-center gap-1.5 text-center transition-all ${
                activeTab === 'settings' ? 'bg-indigo-650/40 border-indigo-500 text-indigo-300' : 'bg-slate-900/60 border-slate-800/80 text-slate-300 hover:bg-slate-800'
              }`}
            >
              <span className="text-xl">⚙️</span>
              <span className="text-[10px] font-black font-sans uppercase">Templates</span>
            </button>
            
            <button 
              onClick={() => { setActiveTab('students'); setIsMoreMenuOpen(false); }}
              className={`col-span-2 p-2.5 rounded-xl border flex items-center justify-center gap-2 transition-all ${
                activeTab === 'students' ? 'bg-indigo-650/40 border-indigo-500 text-indigo-300' : 'bg-slate-900/60 border-slate-800/80 text-slate-300 hover:bg-slate-800'
              }`}
            >
              <span className="text-base">🎓</span>
              <span className="text-xs font-black font-sans uppercase">Students Ledger</span>
            </button>
          </div>
        </div>
      )}

      {/* Drawer Overlay for Mobile view drawer */}
      {isSidebarOpen && (
        <div 
          onClick={() => setIsSidebarOpen(false)}
          className="fixed inset-0 bg-slate-950/75 backdrop-blur-sm z-30 md:hidden animate-fade-in"
        ></div>
      )}

      {/* Edit Counselor Profile Modal */}
      {isEditProfileOpen && (
        <div className="fixed inset-0 bg-slate-950/75 backdrop-blur-xs z-50 flex items-center justify-center p-4 animate-fade-in" id="modal-edit-counselor-profile">
          <div className="bg-white rounded-2xl max-w-sm w-full shadow-2xl border border-slate-200/50 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            {/* Header */}
            <div className="px-5 py-4 bg-indigo-650 text-white flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold font-sans tracking-tight">Edit Counselor Profile</h3>
                <p className="text-[10px] text-white/85 mt-0.5">Update displayed counselor identity</p>
              </div>
              <button 
                onClick={() => setIsEditProfileOpen(false)}
                className="text-white/80 hover:text-white p-1 hover:bg-white/10 rounded-lg transition-colors cursor-pointer text-xs"
                id="btn-close-edit-counselor-modal"
              >
                ✕
              </button>
            </div>

            {/* Form Body */}
            <form onSubmit={(e) => {
              e.preventDefault();
              const formData = new FormData(e.currentTarget);
              const nameValue = formData.get("name")?.toString().trim();
              const titleValue = formData.get("title")?.toString().trim();
              
              if (nameValue) {
                setCounselorName(nameValue);
                try {
                  localStorage.setItem("edugrowth_counselor_name", nameValue);
                } catch {}
              }
              if (titleValue) {
                setCounselorTitle(titleValue);
                try {
                  localStorage.setItem("edugrowth_counselor_title", titleValue);
                } catch {}
              }
              setIsEditProfileOpen(false);
            }} className="p-5 space-y-4">
              <div className="space-y-1">
                <label className="text-[10px] uppercase font-bold text-slate-500 tracking-wider block" htmlFor="counselor-name-input">
                  Counsellor Name
                </label>
                <input 
                  type="text"
                  id="counselor-name-input"
                  name="name"
                  required
                  defaultValue={counselorName}
                  placeholder="e.g. Kunal Verma"
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-550 transition-all font-medium bg-slate-50"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] uppercase font-bold text-slate-500 tracking-wider block" htmlFor="counselor-title-input">
                  Role / Title
                </label>
                <input 
                  type="text"
                  id="counselor-title-input"
                  name="title"
                  required
                  defaultValue={counselorTitle}
                  placeholder="e.g. Senior admissions advisor"
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-550 transition-all font-medium bg-slate-50"
                />
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-end space-x-2 pt-3 border-t border-slate-100">
                <button 
                  type="button"
                  onClick={() => setIsEditProfileOpen(false)}
                  className="px-3 py-1.5 text-[11px] font-semibold text-slate-600 hover:bg-slate-100 transition-all rounded-lg active:scale-95 cursor-pointer"
                  id="btn-cancel-edit-counselor"
                >
                  Cancel
                </button>
                <button 
                  type="submit"
                  className="px-4 py-1.5 bg-indigo-600 text-white text-[11px] font-bold font-sans uppercase tracking-wider hover:bg-indigo-700 transition-all rounded-lg shadow-sm hover:shadow active:scale-95 cursor-pointer"
                  id="btn-save-edit-counselor"
                >
                  Save Profile
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
